
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □                  「アカウント別計画工数出力ツール」サブプログラム（制御系）                  □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「期間」や「アカウント選択」など                                                □
// □  ［アカウント別計画工数出力ツール］のインターフェイス操作の制御系の処理を実施します。        □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  ClickAddAccountButton()       ・・・ アカウント選択の［追加（→）］ボタンクリック時の制御   □
// □  ClickDelAccountButton()       ・・・ アカウント選択の［削除（←）］ボタンクリック時の制御   □
// □  ClickAllAccountSelectButton() ・・・ ［全選択］ボタンクリック時の制御                       □
// □  ChengePeriodSelectBox()       ・・・ 期間選択時の制御                                       □
// □  SetDayList()                  ・・・ ［条件設定：期間］の［日］のリストを設定する           □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// アカウント選択の［追加（→）］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：［アカウント一覧］で選択されたアカウントを［指定アカウント」に追加します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickAddAccountButton() {
// 変更箇所の指定
	var selectAL	= document.getElementsByName("accountList")[0];
	var optionAL	= selectAL.getElementsByTagName("option");

	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

// アカウント一覧で選択されているアカウントの検索
	for (var i = 0; i < optionAL.length; i++) {
		if (optionAL[i].selected) {

		// 追加フラグ（0:追加しない,1:追加する）
			var addFlag = 1;

		// 指定アカウントの重複回避処理
			for (var j = 0; j < optionTA.length; j++) {
				if (document.setting.accountList.options[i].value == document.setting.targetAccount.options[j].value) {
					addFlag = 0;
				}
			}

		// 追加フラグが1のとき指定用のリストに追加
			if (addFlag == 1) {
			// アカウント名を格納したテキストノード作成
				var optionText	= document.createTextNode(document.setting.accountList.options[i].text);

			// optionタグの作成
				var newOption	= document.createElement("option");

			// optionタグのvalue属性にアカウントIDを格納
				newOption.getAttributeNode('value').nodeValue = document.setting.accountList.options[i].value;

			// タグの組み立て
				newOption.appendChild(optionText);
				selectTA.appendChild(newOption);
			}

		// 非選択状態にする
			optionAL[i].selected = "";
		}
	}

}


// =================================================================================================
// アカウント選択の［削除（←）］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：［指定アカウント］で選択されたアカウントを削除します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickDelAccountButton() {
// 対象の指定
	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

	var tempLength = optionTA.length;

// 選択箇所の検索と削除
	for (var i = 0; i < tempLength; i++) {
		if (optionTA[i].selected) {
			selectTA.removeChild(optionTA[i]);
			tempLength--;
			i--;
		}
	}
}


// =================================================================================================
// ［全選択］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：セレクトボックス内の要素すべてを選択状態にします。
// 入力値　：target　…　対象のセレクトボックス（0：アカウント一覧,1：指定アカウント）
// 戻り値　：無
// =================================================================================================
function ClickAllAccountSelectButton(target) {
// 変更箇所の指定用の変数
	var selectBox;

// 対象のセレクトボックスの選択
	if (target == 0) {
		selectBox = document.getElementsByName("accountList")[0];
	} else {
		selectBox = document.getElementsByName("targetAccount")[0];
	}

// option要素の配列の取得
	var arrayOption = selectBox.getElementsByTagName("option");

// 全選択
	for (var i = arrayOption.length; 0 < i; i--) {
		arrayOption[i - 1].selected = "true";
	}
}


// =================================================================================================
// 期間選択時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：期間変更時、開始日と終了日に矛盾が発生した場合、変更していない方の日付を調整します。
// 入力値　：type　…　変更の種類（0：開始日の［年］または［月］を変更,
// 　　　　　　　　　　　　　　　　1：終了日の［年］または［月］を変更,
// 　　　　　　　　　　　　　　　　2：開始日の［日］を変更,
// 　　　　　　　　　　　　　　　　3：終了日の［日］を変更）
// 戻り値　：無
// =================================================================================================
function ChengePeriodSelectBox(type) {
// 入力値の取得
	var startYearValue		= document.setting.startYear.value;
	var startMonthValue		= document.setting.startMonth.value;
	var startDayValue		= document.setting.startDay.value;
	var finishYearValue		= document.setting.finishYear.value;
	var finishMonthValue	= document.setting.finishMonth.value;
	var finishDayValue		= document.setting.finishDay.value;

// ［年］または［月］を変更時に［日］のリストを設定する
	switch (type) {
		case 0:
			SetDayList(startYearValue, startMonthValue, startDayValue, type);
			break;
		case 1:
			SetDayList(finishYearValue, finishMonthValue, finishDayValue, type);
			break;
	}

// 選択日の再取得
	startDayValue	= document.setting.startDay.value;
	finishDayValue	= document.setting.finishDay.value;

// 月または日が1桁の場合に0を付与
	if (startMonthValue < 10) {
		startMonthValue = "0" + startMonthValue;
	}
	if (finishMonthValue < 10) {
		finishMonthValue = "0" + finishMonthValue;
	}
	if (startDayValue < 10) {
		startDayValue = "0" + startDayValue;
	}
	if (finishDayValue < 10) {
		finishDayValue = "0" + finishDayValue;
	}

// 比較用の文字列作成
	var startDate	= Number(startYearValue + startMonthValue + startDayValue);
	var finishDate	= Number(finishYearValue + finishMonthValue + finishDayValue);

	// 開始日と終了日に矛盾が発生した場合に調整する
	if (finishDate < startDate) {
		switch (type) {
			case 0:
			case 2:
			// 開始日変更時は、終了日を開始日と同一の年月日に変更する
				document.setting.finishYear.selectedIndex	= document.setting.startYear.selectedIndex;
				document.setting.finishMonth.selectedIndex	= document.setting.startMonth.selectedIndex;
				SetDayList(document.setting.startYear.value, document.setting.startMonth.value, document.setting.startDay.value, 1)
				break;
			case 1:
			case 3:
			// 終了日変更時は、開始日を終了日と同一の年月日に変更する
				document.setting.startYear.selectedIndex	= document.setting.finishYear.selectedIndex;
				document.setting.startMonth.selectedIndex	= document.setting.finishMonth.selectedIndex;
				SetDayList(document.setting.finishYear.value, document.setting.finishMonth.value, document.setting.finishDay.value, 0)
				break;
		}
	}
}

// =================================================================================================
// ［条件設定：期間］の［日］のリストを設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：年月に合わせて［日］のリストを設定します。
// 入力値　：type　…　変更対象の種類（0：開始日の変更,1：終了日の変更）
// 戻り値　：無
// =================================================================================================
function SetDayList(selectYaer, selectMonth, selectDay, type) {
// 削除対象のリストを持つselectタグの決定
	switch (type) {
		case 0:
			var targetSelectTag	= document.getElementsByName("startDay")[0];
			break;
		case 1:
			var targetSelectTag	= document.getElementsByName("finishDay")[0];
			break;
		default:
			return;
			break;
	}

	while (targetSelectTag.firstChild) {
	// optionタグの削除
	  targetSelectTag.removeChild(targetSelectTag.firstChild);
	}

// ［日］のセレクトボックスの設定
	var endDay = GetMonthEndDay(selectYaer, selectMonth);
	for (var i = 0; i < endDay; i++) {
	// テキストノードの作成
		var optionTextDay	= document.createTextNode(i + 1);

	// optionタグの作成
		var optionDay	= document.createElement("option");

	// valueの設定
		optionDay.getAttributeNode('value').nodeValue	= i + 1;

	// optionタグにテキストノードを追加
		optionDay.appendChild(optionTextDay);

	// selectタグにoptionタグを追加
		targetSelectTag.appendChild(optionDay);
	}

// 選択日の設定
	if (endDay < selectDay) {
	// 選択日を月の末日に変更
		selectDay = endDay
	}

	switch (type) {
		case 0:
			document.setting.startDay.selectedIndex		= selectDay - 1;
			break;
		case 1:
			document.setting.finishDay.selectedIndex	= selectDay - 1;
			break;
	}
}