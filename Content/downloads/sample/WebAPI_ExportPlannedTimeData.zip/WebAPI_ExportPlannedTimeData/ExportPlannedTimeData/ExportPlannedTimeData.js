
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □               「アカウント別計画工数出力ツール」メインプログラム（情報取得系）               □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「タスクツリー」や「条件設定に利用するアカウントの一覧」など                    □
// □  ［アカウント別計画工数出力ツール］で行う情報取得系の処理を実施します。                      □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  SetDefaultSettingView()          ・・・ 条件設定画面の初期値を設定する                      □
// □  GetSectionDataList()             ・・・ 組織情報の一覧を取得する                            □
// □  GetAccountDataList()             ・・・ アカウント情報の一覧を取得する                      □
// □  ChangeSectionFilter()            ・・・ 組織フィルタ利用時アカウント一覧の情報を絞り込む    □
// □  ExportPlannedTimeData() 　　　   ・・・ タイムシートの情報を取得し、計画工数情報を出力する  □
// □  GetAssignedProjectList()         ・・・ タスクツリーのプロジェクト一覧を情報を取得する      □
// □  GetAssignedTaskList()            ・・・ タスクツリーを情報を取得する                        □
// □  GetChildrenWBSNode()             ・・・ 子ノードの情報取得する                              □
// □  AddArrayAccountTask()            ・・・ ノードの情報取得する                                □
// □  GetTaskDailyPlannedTime()        ・・・ 一日あたりの計画工数を取得する                      □
// □  CreateQueryParameterDate()       ・・・ クエリパラメータ用の日付文字列を作成する            □
// □  OutputFile()                     ・・・ 取得した情報をファイルに出力する                    □
// □  ReadSampleConfig()               ・・・ 「SampleConfig.xml」ファイルの情報を読み込む        □
// □  ReadLoginAccountData()           ・・・ ログイン情報を読み込む                              □
// □  ChangeSettingView()              ・・・ 設定画面表示切替の制御                              □
// □  CheckHttpRequestResponse()       ・・・ HTTPリクエストのレスポンス情報の確認する            □
// □  GetMonthEndDay()                 ・・・ 月の末日を取得する                                  □
// □  CreateMinuteToHour()             ・・・ 分単位から時間単位の時刻を作成する                  □
// □  CreateDisplayDate()              ・・・ 表示用日付文字列を作成する                          □
// □  SetDefaultPeriod()               ・・・ ［条件設定：期間］の初期値を設定する                □
// □  OffsetValue()                    ・・・ プログラム内の変数を初期化する                      □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// 内部共通変数の宣言
// -------------------------------------------------------------------------------------------------
// 概要　　：「予実情報出力ツール」で利用する共通の変数を宣言します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
// ログイン情報
	var loginName;		// ログイン名
	var loginPass;		// パスワード

// 接続先情報
	var ServerName;		// サーバーマシン名（ホスト名）
	var TTFXWebServer;	// Web サイト名

// アカウント一覧用の配列
	var arrayAccountId;				// アカウントIDの配列
	var arrayAccountName;			// アカウント名の配列
	var arrayAccountCode;			// アカウントコードの配列
	var arrayAccountSectionId;		// アカウントの組織IDの配列
	var arrayAccountSectionName;	// アカウントの組織名の配列
	var arrayAccountRoleName;		// アカウントの役割名の配列

// 集計用配列の宣言（アカウント×タスク）
	var idCount;							// idカウンタ
	var arrayAccountTaskId;					// アカウント×タスクのID
	var	arrayAccountTaskNodeId;				// ノードID
	var	arrayAccountTaskAccountId;			// アカウントID
	var arrayAccountTaskAccoutCode;			// アカウントコード
	var arrayAccountTaskAccoutName;			// アカウント名
	var arrayAccountTaskSectionName;		// 組織名
	var arrayAccountTaskRoleName;			// 役割名
	var arrayAccountTaskProjectCode;		// プロジェクトコード
	var arrayAccountTaskProjectName;		// プロジェクト名
	var arrayAccountTaskOutlineNumber;		// アウトライン番号
	var arrayAccountTaskNodePath;			// ノードパス
	var arrayAccountTaskTaskName;			// タスク名
	var arrayAccountTaskStartDate;			// 開始日
	var arrayAccountTaskFinishDate;			// 終了日
	var arrayAccountTaskPlannedTime;		// 計画工数
	var arrayAccountTaskDailyPlannedTime;	// 一日あたりの計画工数

// 集計用配列の宣言（アカウント×タスク×日付）
	var arrayAccountTaskDateId;				// アカウント×タスク×日付のID
	var arrayAccountTaskDateAccoutCode;		// アカウントコード
	var arrayAccountTaskDateAccoutName;		// アカウント名
	var arrayAccountTaskDateSectionName;	// 組織名
	var arrayAccountTaskDateRoleName;		// 役割名
	var arrayAccountTaskDateProjectCode;	// プロジェクトコード
	var arrayAccountTaskDateProjectName;	// プロジェクト名
	var arrayAccountTaskDateOutlineNumber;	// アウトライン番号
	var arrayAccountTaskDateNodePath;		// ノードパス
	var arrayAccountTaskDateTaskName;		// タスク名
	var arrayAccountTaskDateDate;			// 日付
	var arrayAccountTaskDatePlannedTime;	// 計画工数

// 入力情報
	var startDate;	// 集計対象期間の開始日（YYYY-MM-DD形式）
	var finishDate;	// 集計対象期間の終了日（YYYY-MM-DD形式）

// エラー処理用変数
	var error_MSG;	// エラーメッセージ
	var error_Flag;	// エラーフラグ（0:エラー無し、1：エラー有り）


// =================================================================================================
// 条件設定画面の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、条件設定画面の初期値を設定します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultSettingView() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 接続先情報の確認
	if (error_Flag == 0) {
		ReadSampleConfig();
	}

// ログイン情報の確認
	if (error_Flag == 0) {
		ReadLoginAccountData();
	}

// 組織一覧の取得と表示
	if (error_Flag == 0) {
		GetSectionDataList();
	}

// アカウント一覧の取得と表示
	if (error_Flag == 0) {
		GetAccountDataList();
	}

// 設定画面の設定
	if (error_Flag == 0) {
	// 期間のセレクトボックスの設定
		SetDefaultPeriod();

	// 設定画面の表示
		ChangeSettingView();
	}

// エラーの表示
	if (error_Flag == 1) {
	// ログイン画面に戻る
		window.location.href = "./login.html";
		alert(error_MSG);
	}
}


// =================================================================================================
// 組織情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：組織一覧を取得し、組織フィルタを表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetSectionDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/sections";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

		var arraySection = xml.getElementsByTagName("section");

	// 組織フィルタの一覧の表示
		var selectSF = document.getElementsByName("sectionFilter")[0];

		for (var i = 0; i < arraySection.length; i++) {
			var sectionId	= arraySection[i].getElementsByTagName("id")[0].text;
			var sectionName	= arraySection[i].getElementsByTagName("name")[0].text;

		// 組織名のテキストノード作成
			var optionText = document.createTextNode(sectionName);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = sectionId;

		// 組立
			newOption.appendChild(optionText);
			selectSF.appendChild(newOption);
		}
	}
}


// =================================================================================================
// アカウント情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetAccountDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/accounts";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

		var arrayAccount = xml.getElementsByTagName("account");

	// 配列の初期化
		arrayAccountId			= new Array();
		arrayAccountName		= new Array();
		arrayAccountCode		= new Array();
		arrayAccountSectionId	= new Array();
		arrayAccountSectionName	= new Array();
		arrayAccountRoleName	= new Array();

	// アカウント一覧を配列に格納
		for (var i = 0; i < arrayAccount.length; i++) {
			arrayAccountId[i]											= arrayAccount[i].getElementsByTagName("id")[0].text;
			arrayAccountName		["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("name")[0].text;
			arrayAccountCode		["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("code")[0].text;
			arrayAccountSectionId	["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("sectionId")[0].text;
			arrayAccountSectionName	["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("sectionName")[0].text;
			arrayAccountRoleName	["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("roleName")[0].text;
		}

	// アカウント一覧の作成
		var selectAL = document.getElementsByName("accountList")[0];

		for (var i = 0; i < arrayAccount.length; i++) {
		// アカウント名のテキストノード作成
			var optionText = document.createTextNode(arrayAccountName["AccountId_" + arrayAccountId[i]]);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = arrayAccountId[i];

		// 組立
			newOption.appendChild(optionText);
			selectAL.appendChild(newOption);
		}
	}
}


// =================================================================================================
// 組織フィルタ利用時アカウント一覧の情報を絞り込む
// -------------------------------------------------------------------------------------------------
// 概要　　：組織フィルタで組織選択時に、アカウント一覧の情報をすべて削除し、
// 　　　　　選択組織に所属するアカウントに絞り込んで再表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSectionFilter() {
// 選択中の組織IDの取得
	var selectSectionId = document.setting.sectionFilter.value;

// アカウント一覧の削除
	var selectAL = document.getElementsByName("accountList")[0];

	while (selectAL.firstChild) {
	  selectAL.removeChild(selectAL.firstChild);
	}

// アカウント一覧の再作成
	for (var i = 0; i < arrayAccountId.length; i++) {
	// 選択中の組織で絞り込み
		if ((selectSectionId == arrayAccountSectionId["AccountId_" + arrayAccountId[i]]) || (selectSectionId == 0)) {
		// アカウント名のテキストノード作成
			var optionText = document.createTextNode(arrayAccountName["AccountId_" + arrayAccountId[i]]);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = arrayAccountId[i];

		// 組立
			newOption.appendChild(optionText);
			selectAL.appendChild(newOption);
		}
	}
}


// =================================================================================================
// 指定アカウントのタイムシートの情報を取得し、計画工数の情報を出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントのタスクツリーの情報を取得して
// 　　　　　一日のあたりの計画工数を算出し、計画工数の情報を出力します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ExportPlannedTimeData() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 入力情報の取得
	var inputStartYear		= document.setting.startYear.value;
	var inputStartMonth		= document.setting.startMonth.value;
	var inputStartDay		= document.setting.startDay.value;
	var inputFinishYear		= document.setting.finishYear.value;
	var inputFinishMonth	= document.setting.finishMonth.value;
	var inputFinishDay		= document.setting.finishDay.value;

	startDate	= new Date(inputStartYear, inputStartMonth -1, inputStartDay);
	finishDate	= new Date(inputFinishYear, inputFinishMonth - 1, inputFinishDay);

// 変数の初期化
	idCount	= -1;
	arrayAccountTaskId					= new Array();
	arrayAccountTaskNodeId				= new Array();
	arrayAccountTaskAccountId			= new Array();
	arrayAccountTaskAccoutCode			= new Array();
	arrayAccountTaskAccoutName			= new Array();
	arrayAccountTaskSectionName			= new Array();
	arrayAccountTaskRoleName			= new Array();
	arrayAccountTaskProjectCode			= new Array();
	arrayAccountTaskProjectName			= new Array();
	arrayAccountTaskOutlineNumber		= new Array();
	arrayAccountTaskNodePath			= new Array();
	arrayAccountTaskTaskName			= new Array();
	arrayAccountTaskStartDate			= new Array();
	arrayAccountTaskFinishDate			= new Array();
	arrayAccountTaskPlannedTime			= new Array();
	arrayAccountTaskDailyPlannedTime	= new Array();

	arrayAccountTaskDateId				= new Array();
	arrayAccountTaskDateAccoutCode		= new Array();
	arrayAccountTaskDateAccoutName		= new Array();
	arrayAccountTaskDateSectionName		= new Array();
	arrayAccountTaskDateRoleName		= new Array();
	arrayAccountTaskDateProjectCode		= new Array();
	arrayAccountTaskDateProjectName		= new Array();
	arrayAccountTaskDateOutlineNumber	= new Array();
	arrayAccountTaskDateNodePath		= new Array();
	arrayAccountTaskDateTaskName		= new Array();
	arrayAccountTaskDateDate			= new Array();
	arrayAccountTaskDatePlannedTime		= new Array();

// 指定アカウントのタスクツリーを取得
	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

	if (optionTA.length != 0) {
		for (var i = 0; i < optionTA.length; i++) {
			var tempId = document.setting.targetAccount.options[i].value;

		// 該当アカウントのタスクツリーの取得
			GetAssignedProjectList(tempId);
		}
	} else {
		error_Flag	= 1;
		error_MSG	= error_MSG + "アカウントが指定されていません。";
	}

// 日ごとのデータに換算し、配列に格納する
	if (error_Flag == 0) {
		idCount = 0;

		if (arrayAccountTaskId.length != 0) {
		// 全アカウントの全タスクを処理
			for (var j = 0; j < arrayAccountTaskId.length; j++) {
			// 指定期間の日ごとにループ
				for (var dateCcount = new Date(startDate); dateCcount <= finishDate; dateCcount.setDate(dateCcount.getDate() + 1)) {
				// 日ごとに各項目用配列に格納
					arrayAccountTaskDateId[idCount] = arrayAccountTaskId[j] + "_Date_" + CreateQueryParameterDate(dateCcount);
					arrayAccountTaskDateAccoutCode		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskAccoutCode		[arrayAccountTaskId[j]];
					arrayAccountTaskDateAccoutName		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskAccoutName		[arrayAccountTaskId[j]];
					arrayAccountTaskDateSectionName		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskSectionName		[arrayAccountTaskId[j]];
					arrayAccountTaskDateRoleName		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskRoleName		[arrayAccountTaskId[j]];
					arrayAccountTaskDateProjectCode		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskProjectCode		[arrayAccountTaskId[j]];
					arrayAccountTaskDateProjectName		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskProjectName		[arrayAccountTaskId[j]];
					arrayAccountTaskDateOutlineNumber	[arrayAccountTaskDateId[idCount]] = arrayAccountTaskOutlineNumber	[arrayAccountTaskId[j]];
					arrayAccountTaskDateNodePath		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskNodePath		[arrayAccountTaskId[j]];
					arrayAccountTaskDateTaskName		[arrayAccountTaskDateId[idCount]] = arrayAccountTaskTaskName		[arrayAccountTaskId[j]];

				// 計画期間内かの判定
					var tempStartDate	= new Date(arrayAccountTaskStartDate[arrayAccountTaskId[j]]);
					var tempFinishDate	= new Date(arrayAccountTaskFinishDate[arrayAccountTaskId[j]]);
					if ((tempStartDate <= dateCcount) && (dateCcount <= tempFinishDate)) {
					// 曜日の判定
						switch (dateCcount.getDay()) {
							case 0:
							case 6:
							// 土日の場合は計画工数に0を格納
								arrayAccountTaskDatePlannedTime	[arrayAccountTaskDateId[idCount]] = CreateMinuteToHour(0);
								break;
							default:
							// 土日以外の場合は対象タスクの一日当たりの計画工数を格納
								arrayAccountTaskDatePlannedTime	[arrayAccountTaskDateId[idCount]] = arrayAccountTaskDailyPlannedTime[arrayAccountTaskId[j]];
								break;
						}
					} else {
					// 計画期間外の場合は計画工数に0を格納
						arrayAccountTaskDatePlannedTime	[arrayAccountTaskDateId[idCount]] = CreateMinuteToHour(0);
					}

					arrayAccountTaskDateDate[arrayAccountTaskDateId[idCount]]	= CreateDisplayDate(dateCcount, 1);
					idCount++;
				}
			}
		} else {
			error_Flag	= 1;
			error_MSG	= error_MSG + "取得可能なノードがありません。";
		}
	}

// 情報の出力
	if (error_Flag == 0) {
	// 情報の有無の確認
		if (arrayAccountTaskDateId.length != 0) {
			if (document.setting.outputSwitch[0].checked) {
			// TSVファイル出力
				OutputFile(0);
			} else if (document.setting.outputSwitch[1].checked) {
			// CSVファイル出力
				OutputFile(1);
			}

		} else {
			error_Flag	= 1;
			error_MSG	= error_MSG + "取得可能な情報がありません。";
		}
	}

// エラーの表示
	if (error_Flag == 1) {
		alert(error_MSG);
	}

// 変数の初期化
	OffsetValue();
}


// =================================================================================================
// アカウントのタスクツリーのプロジェクト一覧を情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントのタスクツリーのプロジェクト一覧を取得し、
// 　　　　　プロジェクトごとにタスクツリーを取得します。
// 入力値　：accountId ･･･ 取得対象のアカウントID
// 戻り値　：無
// =================================================================================================
function GetAssignedProjectList(accountId) {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/assignedProjects";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayAssignedProject = xml.getElementsByTagName("assignedProject");

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayAssignedProject.length; i++) {
		var tempProjectId = arrayAssignedProject[i].getElementsByTagName("id")[0].text;
		GetAssignedTaskList(accountId, tempProjectId)
	}
}


// =================================================================================================
// アカウントのタスクツリーを情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントの指定プロジェクトのタスクツリーの情報を取得します。
// 入力値　：accountId ･･･ 取得対象のアカウントID
// 　　　　　projectId ･･･ 取得対象のプロジェクトID
// 戻り値　：無
// =================================================================================================
function GetAssignedTaskList(accountId, projectId) {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/assignedProjects/" + projectId + "/assignedTasks";
	var queryParameter	= "?limit=0&convertType=tree&includeTaskPackage=TRUE";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayAssignedTask = xml.getElementsByTagName("assignedTasks")[0].childNodes;

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayAssignedTask.length; i++) {
	// ノード名、ノードコードの取得とノードパスの作成
		var tempProjectName = arrayAssignedTask[i].getElementsByTagName("projectName")[0].text;
		var tempProjectCode = arrayAssignedTask[i].getElementsByTagName("projectCode")[0].text;
		var tempNodePath = "";

		if (tempProjectCode == "") {
			tempNodePath = tempProjectName + "/" + arrayAssignedTask[i].getElementsByTagName("name")[0].text;
		}
		else {
			tempNodePath =  "[" + tempProjectCode + "]" + tempProjectName + "/" + arrayAssignedTask[i].getElementsByTagName("name")[0].text;
		}

	// ノードの種類の判定
		switch (arrayAssignedTask[i].getElementsByTagName("kind")[0].text) {
			case "task":
			// タスクの場合、各項目用配列に格納
				idCount++;
				arrayAccountTaskId[idCount] = "AccountId_" + accountId + "_TaskId_" + arrayAssignedTask[i].getElementsByTagName("nodeId")[0].text;
				arrayAccountTaskNodeId			[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("nodeId")[0].text;
				arrayAccountTaskAccountId		[arrayAccountTaskId[idCount]] = accountId;
				arrayAccountTaskAccoutCode		[arrayAccountTaskId[idCount]] = arrayAccountCode		["AccountId_" + accountId];
				arrayAccountTaskAccoutName		[arrayAccountTaskId[idCount]] = arrayAccountName		["AccountId_" + accountId];
				arrayAccountTaskSectionName		[arrayAccountTaskId[idCount]] = arrayAccountSectionName	["AccountId_" + accountId];
				arrayAccountTaskRoleName		[arrayAccountTaskId[idCount]] = arrayAccountRoleName	["AccountId_" + accountId];
				arrayAccountTaskProjectCode		[arrayAccountTaskId[idCount]] = tempProjectCode;
				arrayAccountTaskProjectName		[arrayAccountTaskId[idCount]] = tempProjectName;
				arrayAccountTaskOutlineNumber	[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("outlineNumber")[0].text;
				arrayAccountTaskNodePath		[arrayAccountTaskId[idCount]] = tempNodePath;
				arrayAccountTaskTaskName		[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("name")[0].text;
				arrayAccountTaskStartDate		[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("plannedStartDate")[0].text;
				arrayAccountTaskFinishDate		[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("plannedFinishDate")[0].text;
				arrayAccountTaskPlannedTime		[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("plannedTime")[0].text;
				arrayAccountTaskDailyPlannedTime[arrayAccountTaskId[idCount]] = GetTaskDailyPlannedTime(arrayAccountTaskPlannedTime[arrayAccountTaskId[idCount]],
																										arrayAccountTaskStartDate[arrayAccountTaskId[idCount]],
																										arrayAccountTaskFinishDate[arrayAccountTaskId[idCount]]);
				break;
			case "taskPackage":
			// タスクパッケージの場合、子ノードの情報取得
				GetChildrenWBSNode(arrayAssignedTask[i], 2, tempNodePath, accountId);
				break;
		}
	}
}


// =================================================================================================
// 子ノードの情報取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定タスクパッケージ内の子ノードの情報を取得します。
// 入力値　：assignedTask ･･･ 対象のassignedTaskオブジェクト（タスクパッケージのみ）
// 　　　　　levelCount   ･･･ 対象ノードのアウトラインレベル
// 　　　　　nodePath     ･･･ 対象ノードのノードパス
// 　　　　　accountId    ･･･ 取得対象のアカウントID
// 戻り値　：無
// =================================================================================================
function GetChildrenWBSNode(assignedTask, levelCount, nodePath, accountId) {
	var childAssignedTasks = assignedTask.getElementsByTagName("children")[0].childNodes;

// 子ノードの情報を配列への格納
	for (var c = 0; c < childAssignedTasks.length; c++) {
		var childAssignedTask = childAssignedTasks[c];
		var tempNodePath = AddArrayAccountTask(childAssignedTask, nodePath, accountId);

	// ノードの種類とアウトラインレベルの判定
		if ((childAssignedTask.getElementsByTagName("kind")[0].text == "taskPackage") && (levelCount < 16)) {
		// 次階層の処理へ
			levelCount++;
			GetChildrenWBSNode(childAssignedTask, levelCount, tempNodePath, accountId);
			levelCount--;
		}
	}
}


// =================================================================================================
// ノードの情報取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定ノードの情報を取得します。
// 入力値　：assignedTask ･･･ 対象のassignedTaskオブジェクト
// 　　　　　nodePath     ･･･ 親ノードのノードパス
// 　　　　　accountId    ･･･ 取得対象のアカウントID
// 戻り値　：thisNodePath ･･･ 対象ノードのノードパス
// =================================================================================================
function AddArrayAccountTask(assignedTask, nodePath, accountId) {
// ノードパスの作成
	var thisNodePath = nodePath + "/" + assignedTask.getElementsByTagName("name")[0].text;

// ノードの種類の判定
	if (assignedTask.getElementsByTagName("kind")[0].text == "task") {
	// タスクの場合各項目用配列に格納
		idCount++;
		arrayAccountTaskId[idCount] = "AccountId_" + accountId + "_TaskId_" + assignedTask.getElementsByTagName("nodeId")[0].text;
		arrayAccountTaskNodeId			[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("nodeId")[0].text;
		arrayAccountTaskAccountId		[arrayAccountTaskId[idCount]] = accountId;
		arrayAccountTaskAccoutCode		[arrayAccountTaskId[idCount]] = arrayAccountCode		["AccountId_" + accountId];
		arrayAccountTaskAccoutName		[arrayAccountTaskId[idCount]] = arrayAccountName		["AccountId_" + accountId];
		arrayAccountTaskSectionName		[arrayAccountTaskId[idCount]] = arrayAccountSectionName	["AccountId_" + accountId];
		arrayAccountTaskRoleName		[arrayAccountTaskId[idCount]] = arrayAccountRoleName	["AccountId_" + accountId];
		arrayAccountTaskProjectCode		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("projectCode")[0].text;
		arrayAccountTaskProjectName		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("projectName")[0].text;
		arrayAccountTaskOutlineNumber	[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("outlineNumber")[0].text;
		arrayAccountTaskNodePath		[arrayAccountTaskId[idCount]] = thisNodePath;
		arrayAccountTaskTaskName		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("name")[0].text;
		arrayAccountTaskStartDate		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("plannedStartDate")[0].text;
		arrayAccountTaskFinishDate		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("plannedFinishDate")[0].text;
		arrayAccountTaskPlannedTime		[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("plannedTime")[0].text;
		arrayAccountTaskDailyPlannedTime[arrayAccountTaskId[idCount]] = GetTaskDailyPlannedTime(arrayAccountTaskPlannedTime[arrayAccountTaskId[idCount]],
																								arrayAccountTaskStartDate[arrayAccountTaskId[idCount]],
																								arrayAccountTaskFinishDate[arrayAccountTaskId[idCount]]);

	}

	return thisNodePath;
}


// =================================================================================================
// 一日あたりの計画工数を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：1日あたりの計画工数を算出し、返します。
// 入力値　：taskPlannedTime ･･･ 対象タスクの計画工数
// 　　　　　taskStartDate   ･･･ 対象タスクの計画開始日
// 　　　　　taskFinishDate  ･･･ 対象タスクの計画終了日
// 戻り値　：一日あたりの計画工数
// =================================================================================================
function GetTaskDailyPlannedTime(taskPlannedTime, taskStartDate, taskFinishDate) {
	var dailyPlannedTime;

	if ((taskPlannedTime == 0) || (taskPlannedTime == "1753/01/01") || (taskFinishDate == "1753/01/01")) {
		dailyPlannedTime = 0;
	} else {
	// Date型に変換
		var inputStartDate	= new Date(taskStartDate);	// 開始日
		var inputFinishDate	= new Date(taskFinishDate);	// 終了日

		var workingDayCount = 0;

	// 稼働日数の算出
		for (var dateCcount = new Date(inputStartDate); dateCcount <= inputFinishDate; dateCcount.setDate(dateCcount.getDate() + 1)) {
			switch (dateCcount.getDay()) {
				case 0:
				case 6:
				// 土日はカウントしない
					break;
				default:
				// 土日以外日数をカウント
					workingDayCount++;
					break;
			}
		}

	//　日単位の計画工数を算出
		if (workingDayCount == 0) {
			dailyPlannedTime = 0;
		} else {
			dailyPlannedTime = taskPlannedTime / workingDayCount;
		}
	}

	return(CreateMinuteToHour(dailyPlannedTime));
}

// =================================================================================================
// クエリパラメータ用の日付文字列を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：クエリパラメータ用の日付文字列（YYYY-MM-DD形式）を作成します。
// 入力値　：dateTime ･･･ 日付
// 戻り値　：クエリパラメータ用の日付文字列
// =================================================================================================
function CreateQueryParameterDate(dateTime) {
// 入力値から年、月、日を取得
	var YYYY	= dateTime.getYear();		// 年
	var MM		= dateTime.getMonth() + 1;	// 月
	var DD		= dateTime.getDate();		// 日

// 1桁の場合に0を付与
	if (MM < 10) {
		MM = "0" + MM;
	}
	if (DD < 10) {
		DD = "0" + DD;
	}

// クエリパラメータ用の日付文字列の作成
	return(YYYY + "-" + MM + "-" + DD);
}


// =================================================================================================
// 取得した情報をファイルに出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：情報をTSV形式またはCSV形式でファイルに出力します。
// 入力値　：type ･･･ 出力形式（0:TSV形式,1:CSV形式）
// 戻り値　：無
// =================================================================================================
function OutputFile(type) {
// 上書き確認用フラグ
	var overwriteFlag = true;

// 出力先に指定されているパスとファイル名を取得
	var filename = document.getElementById("output").value;

// 拡張子の確認
	var extension = filename.slice(-4, filename.length);
	extension = extension.toLowerCase()

	switch (type) {
		case 0:
			if (extension != ".tsv") {
				filename = filename + ".tsv";
			}
			break;
		case 1:
			if (extension != ".csv") {
				filename = filename + ".csv";
			}
			break;
	}

// ファイル出力
	try {
	// ファイルシステムオブジェクトの生成
		var FSO =new ActiveXObject("Scripting.FileSystemObject");

	// ファイルの有無の確認
		if (FSO.FileExists(filename)) {
			overwriteFlag = confirm("以下のファイルがすでに存在します。\n上書きしてもよろしいですか。\n\n" + filename);
		}

	// ファイル出力実施
		if (overwriteFlag) {
			var file = FSO.OpenTextFile(filename, 2, true, 0); // 書き込みモード、新規ファイル作成

			switch (type) {
				case 0:	// TSV出力
				// ヘッダー出力
					var STR = "アカウントコード\tアカウント名\t組織\t役割\tプロジェクトコード\tプロジェクト名\tアウトライン番号\tノードパス\tタスク名\t日付\t計画工数\r\n";

				// 情報の出力
					for (var i = 0; i < arrayAccountTaskDateId.length; i++) {
						STR = STR + arrayAccountTaskDateAccoutCode		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateAccoutName		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateSectionName		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateRoleName		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateProjectCode		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateProjectName		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateOutlineNumber	[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateNodePath		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateTaskName		[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDateDate			[arrayAccountTaskDateId[i]] + "\t" +
									arrayAccountTaskDatePlannedTime		[arrayAccountTaskDateId[i]] + "\r\n";
					}
					break;
				case 1:	// CSV出力
				// ヘッダー出力
					var STR = "アカウントコード,アカウント名,組織,役割,プロジェクトコード,プロジェクト名,アウトライン番号,ノードパス,タスク名,日付,計画工数\r\n";

				// 情報の出力
					for (var i = 0; i < arrayAccountTaskDateId.length; i++) {
						STR = STR + arrayAccountTaskDateAccoutCode		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateAccoutName		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateSectionName		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateRoleName		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateProjectCode		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateProjectName		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateOutlineNumber	[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateNodePath		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateTaskName		[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDateDate			[arrayAccountTaskDateId[i]] + "," +
									arrayAccountTaskDatePlannedTime		[arrayAccountTaskDateId[i]] + "\r\n";
					}
					break;
			}

		// ファイルに書き込み
			file.Write(STR);
			file.Close();
			STR = "";
			confirm("以下のとおりファイルを出力しました。\n\n" + filename);
		} else {
			confirm("ファイルの出力はキャンセルされました。");
		}
	} catch (e) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "ファイル出力エラー\n";
		error_MSG	= error_MSG + e.description;
	}
}


// =================================================================================================
// 「SampleConfig.xml」ファイルの情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：「SampleConfig.xml」ファイルの情報を読み込み、サーバーマシン名とWebサイト名を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadSampleConfig() {
// オブジェクト作成
	var ConfigFile = new ActiveXObject("Microsoft.XMLDOM");

// XMLの読み込みを同期に設定
	ConfigFile.async = false;

// configファイルの読み込み
	ConfigFile.load("./../SampleConfig.xml");

	if (ConfigFile.getElementsByTagName("SampleConfig").length == 0) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "SampleConfig.xmlが正常に読み込めません。";
	} else {
	// サーバーマシン名とWeb サイト名の取得
		ServerName		= ConfigFile.getElementsByTagName("ServerName")[0].text;	// サーバーマシン名（ホスト名）
		TTFXWebServer	= ConfigFile.getElementsByTagName("TTFXWebServer")[0].text;	// Webサイト名

		if (ServerName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "SampleConfig.xmlのServerNameにホスト名が入力されていません。\n";
		}

		if (TTFXWebServer == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "SampleConfig.xmlのTTFXWebServerにWebサイト名が入力されていません。";
		}
	}
}


// =================================================================================================
// ログイン情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：URLのクエリパラメータのログイン情報を読み込み、ログイン名とパスワードを取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadLoginAccountData() {
// URLのクエリパラメータの取得
	var loginNameAndPass = location.search;

	if (loginNameAndPass == "") {
		error_Flag	= 1;
		error_MSG	= error_MSG + "login.htmlよりツールを起動してください。";
	} else {
		loginNameAndPass	= loginNameAndPass.substring(1,loginNameAndPass.length);
		var arrayQP			= loginNameAndPass.split("&");

	// ログイン名とパスワードを取得
		loginName	= arrayQP[0].split("=")[1];
		loginPass	= arrayQP[1].split("=")[1];

		if (loginName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "ログイン名を入力してください。";
		}
	}
}


// =================================================================================================
// 設定画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面を非表示にし、設定画面を切り替えます。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSettingView() {
	document.getElementById("settingView").style.display	= "block";
}


// =================================================================================================
// HTTPリクエストのレスポンス情報の確認する
// -------------------------------------------------------------------------------------------------
// 概要　　：HTTPリクエストのレスポンスに応じて、エラーメッセージを設定します。
// 入力値　：responseCode ･･･ レスポンスコード
// 戻り値　：無
// =================================================================================================
function CheckHttpRequestResponse(responseCode) {
	switch (responseCode) {
		case 200:
			break;
		case 400:
			error_Flag	= 1;
			error_MSG	= error_MSG + "パラメータやリクエストに不備があります。";
			break;
		case 401:
			error_Flag	= 1;
			error_MSG	= error_MSG + "認証に失敗しました。\n";
			error_MSG	= error_MSG + "ログイン名またはパスワードに誤りがあります。\n";
			break;
		case 404:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したソース(URI)が存在しません。";
			break;
		case 405:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したHTTPメソッドが使用できません。";
			break;
		case 411:
			error_Flag	= 1;
			error_MSG	= error_MSG + "HTTP リクエストヘッダにContent-Lengthが指定されていません。";
			break;
		case 500:
			error_Flag	= 1;
			error_MSG	= error_MSG + "サーバーでエラーが発生しました。";
			break;
		default:
			error_Flag	= 1;
			error_MSG	= error_MSG + "エラーが発生しました。\n";
			error_MSG	= error_MSG + "SampleConfig.xmlに不備がある可能性があります。";
			break;
	}
}


// =================================================================================================
// 月の末日の取得
// -------------------------------------------------------------------------------------------------
// 概要　　：年と月の情報をもとに、月の末日を取得します。
// 入力値　：year  ･･･ 年
// 　　　　　month ･･･ 月
// 戻り値　：末日の日
// =================================================================================================
function GetMonthEndDay(year, month) {
	var endDay = new Date(year, month, 0);
	return(endDay.getDate());
}


// =================================================================================================
// 分単位から時間単位に変換した時刻を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：分単位から時間単位に変換し、小数第2位まで表示した文字列を作成します。
// 入力値　：minute ･･･ 分
// 戻り値　：小数第2位まで表示した時間の文字列
// =================================================================================================
function CreateMinuteToHour(minute) {
// 分単位から時間単位に変換
	var tempTime = minute / 60;

// 小数第2位まで文字列に変換
	return(tempTime.toFixed(2));
}


// =================================================================================================
// 表示用日付文字列を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：表示用日付文字列（YYYY/MMまたはYYYY/MM/DD形式）を作成します。
// 入力値　：strDate ･･･ 日付
// 　　　　　dayFlag ･･･ 日の表示のフラグ（0:表示しない（YYYY/MM形式）,1:表示する（YYYY/MM/DD形式））
// 戻り値　：日付
// =================================================================================================
function CreateDisplayDate(strDate, dayFlag) {
// 入力値から年、月、日を取得
	var inputDate	= new Date(strDate);		// 日付
	var YYYY		= inputDate.getYear();		// 年
	var MM			= inputDate.getMonth() + 1;	// 月
	var DD			= inputDate.getDate();		// 日

// 1桁の場合に0を付与
	if (MM < 10) {
		MM = "0" + MM;
	}
	if (DD < 10) {
		DD = "0" + DD;
	}

// フラグに応じた表示用日付文字列の作成
	if (dayFlag == 0) {
		return(YYYY + "/" + MM);
	} else {
		return(YYYY + "/" + MM + "/" + DD);
	}
}


// =================================================================================================
// ［条件設定：期間］の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：［条件設定：期間］のセレクトボックスに当年と前後1年を年月を設定し、
// 　　　　　初期選択値として当年と当月を選択する。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultPeriod() {
// 現在の日付の取得
	var today			= new Date();		// 現在の日時
	var thisYear		= today.getYear();	// 現在の年
	var thisMonth		= today.getMonth();	// 現在の月
	var endDay			= GetMonthEndDay(thisYear, thisMonth +1);
	var selectStartDay	= document.getElementsByName("startDay")[0];
	var selectFinishDay	= document.getElementsByName("finishDay")[0];

// 期間のセレクトボックスに当年と前後1年を設定
	for (var i = 0; i < 3; i++) {
		document.setting.startYear.options[i].text		= thisYear - 1 + i;
		document.setting.startYear.options[i].value		= thisYear - 1 + i;
		document.setting.finishYear.options[i].text		= thisYear - 1 + i;
		document.setting.finishYear.options[i].value	= thisYear - 1 + i;
	}

// ［日］のセレクトボックスの設定
	for (var i = 0; i < endDay; i++) {
	// テキストノードの作成
		var optionTextStartDay	= document.createTextNode(i + 1);
		var optionTextFinishDay	= document.createTextNode(i + 1);

	// optionタグの作成
		var optionStartDay	= document.createElement("option");
		var optionFinishDay	= document.createElement("option");

	// valueの設定
		optionStartDay.getAttributeNode('value').nodeValue	= i + 1;
		optionFinishDay.getAttributeNode('value').nodeValue	= i + 1;

	// optionタグにテキストノードを追加
		optionStartDay.appendChild(optionTextStartDay);
		optionFinishDay.appendChild(optionTextFinishDay);

	// selectタグにoptionタグを追加
		selectStartDay.appendChild(optionStartDay);
		selectFinishDay.appendChild(optionFinishDay);
	}

// 初期選択値の設定
	document.setting.startYear.selectedIndex	= 1;
	document.setting.startMonth.selectedIndex	= thisMonth;
	document.setting.startDay.selectedIndex		= today.getDate() - 1;

	document.setting.finishYear.selectedIndex	= 1;
	document.setting.finishMonth.selectedIndex	= thisMonth;
	document.setting.finishDay.selectedIndex	= today.getDate() - 1;
}


// =================================================================================================
// プログラム内の変数を初期化する
// -------------------------------------------------------------------------------------------------
// 概要　　：プログラム内の変数を初期化します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function OffsetValue() {
	idCount = 0;

	arrayAccountTaskId					= new Array();
	arrayAccountTaskNodeId				= new Array();
	arrayAccountTaskAccountId			= new Array();
	arrayAccountTaskAccoutCode			= new Array();
	arrayAccountTaskAccoutName			= new Array();
	arrayAccountTaskSectionName			= new Array();
	arrayAccountTaskRoleName			= new Array();
	arrayAccountTaskProjectCode			= new Array();
	arrayAccountTaskProjectName			= new Array();
	arrayAccountTaskOutlineNumber		= new Array();
	arrayAccountTaskNodePath			= new Array();
	arrayAccountTaskTaskName			= new Array();
	arrayAccountTaskStartDate			= new Array();
	arrayAccountTaskFinishDate			= new Array();
	arrayAccountTaskPlannedTime			= new Array();
	arrayAccountTaskDailyPlannedTime	= new Array();

	arrayAccountTaskDateId				= new Array();
	arrayAccountTaskDateAccoutCode		= new Array();
	arrayAccountTaskDateAccoutName		= new Array();
	arrayAccountTaskDateSectionName		= new Array();
	arrayAccountTaskDateRoleName		= new Array();
	arrayAccountTaskDateProjectCode		= new Array();
	arrayAccountTaskDateProjectName		= new Array();
	arrayAccountTaskDateOutlineNumber	= new Array();
	arrayAccountTaskDateNodePath		= new Array();
	arrayAccountTaskDateTaskName		= new Array();
	arrayAccountTaskDateDate			= new Array();
	arrayAccountTaskDatePlannedTime		= new Array();

	error_MSG	= "";
	error_Flag	= 0;
}
