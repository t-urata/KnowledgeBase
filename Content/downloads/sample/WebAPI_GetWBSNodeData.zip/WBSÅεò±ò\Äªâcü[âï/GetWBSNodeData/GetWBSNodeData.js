
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □                    「WBS情報取得ツール」プログラム                                           □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「プロジェクト情報の一覧の取得」や「WBS情報の表示」など                         □
// □  [WBS情報取得ツール]で行う処理を実施します。                                                 □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  【データ取得系】                                                                            □
// □      GetProjectDataList()        ・・・ プロジェクト情報の一覧を取得する                     □
// □      GetWBSDataList()            ・・・ WBS情報の一覧を取得する                              □
// □      GetSampleConfig()           ・・・ サーバの接続情報を記載した「SampleConfig.xml」       □
// □                                         ファイルの情報を取得する                             □
// □      GetLoginAccountData()       ・・・ ログイン時のURLからログイン情報を取得する            □
// □  【データ操作系】                                                                            □
// □      SetProjectDataList()        ・・・ プロジェクト情報の一覧を画面に設定する               □
// □      SetWBSDataList()            ・・・ WBS情報の一覧を画面に設定する                        □
// □      DeleteDataList()            ・・・ [プロジェクト情報一覧]画面および                     □
// □                                         [WBS情報表示]に表示した一覧情報を削除する            □
// □      CheckHttpRequestResponse()  ・・・ リクエストに対するサーバからのレスポンスを確認する   □
// □  【画面表示系】                                                                              □
// □      DisplayProjectListView()    ・・・ [プロジェクト情報一覧]画面を表示する                 □
// □      DisplayWBSListView()        ・・・ [WBS情報表示]画面を表示する                          □
// □      SwitchView()                ・・・ [プロジェクト情報一覧]画面と[WBS情報表示]画面の      □
// □                                         表示を切り替える                                     □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□

// =================================================================================================
// 内部共通変数の宣言
// -------------------------------------------------------------------------------------------------
// 概要　　：「WBS情報取得ツール」で利用する共通の変数を宣言します。
// =================================================================================================
	// ログイン情報
	var loginName;     // ログイン名
	var loginPassword; // パスワード

	// 接続先情報
	var ServerName;    // サーバーマシン名(ホスト名)
	var TTFXWebServer; // Web サイト名

	// エラー処理用変数
	var errorFlag;    // エラーフラグ(0:エラー無し、1：エラー有り)
	var errorMessage; // エラーメッセージ


// +++++ 【データ取得系】 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// =================================================================================================
// プロジェクト情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIでプロジェクト情報の一覧を取得します。
// 戻り値　：projectCollection ･･･ プロジェクト情報の一覧
// =================================================================================================
function GetProjectDataList() {
	// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var request = new XMLHttpRequest();

	// サーバの応答を待って処理するように設定
	xml.async = false;

	// 送信先URL情報の設定
	var url = "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName = "/projects";
	var queryParameter = "?limit=0";

	// 送信用URLを生成
	url = url + objectName + queryParameter;

	// リクエストの作成・送信
	request.open('GET', url, false, loginName, loginPassword);
	request.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	request.send();

	// リクエストのレスポンスの確認
	CheckHttpRequestResponse(request.status, request.responseXML);

	if (errorFlag == 0) {
		// リクエストの結果の取得
		xml.loadXML(request.responseText);

		// 取得した情報を配列に格納
		var arrayProject = xml.getElementsByTagName("project");

		// 変数の初期化
		var projectCollection = new Array();

		var count = 0;

		// プロジェクト情報の各項目用配列に格納
		for (var i = 0; i < arrayProject.length; i++) {
			// プロジェクト情報の配列内に要素を追加する配列を設定
			projectCollection[count] = new Array();

			// 設定した配列内に要素を格納する
			projectCollection[count].id = arrayProject[i].getElementsByTagName("id")[0].text;
			projectCollection[count].code = arrayProject[i].getElementsByTagName("code")[0].text;
			projectCollection[count].name = arrayProject[i].getElementsByTagName("name")[0].text;
			projectCollection[count].managerId = arrayProject[i].getElementsByTagName("managerId")[0].text;
			projectCollection[count].managerName = arrayProject[i].getElementsByTagName("managerName")[0].text;
			projectCollection[count].sectionName = arrayProject[i].getElementsByTagName("sectionName")[0].text;
			projectCollection[count].startDate = arrayProject[i].getElementsByTagName("plannedStartDate")[0].text;
			projectCollection[count].finishDate = arrayProject[i].getElementsByTagName("plannedFinishDate")[0].text;

			count++;
		}
	}

	// 設定した要素の一覧を返す
	return projectCollection;
}

// =================================================================================================
// WBS情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIでWBS情報の一覧を取得します。
// 入力値　：projectId ･･･ WBS情報を取得するプロジェクトのID
// 戻り値　：nodeCollection ･･･ WBS情報の一覧
// =================================================================================================
function GetWBSDataList(projectId) {

	// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var request = new XMLHttpRequest();

	// サーバの応答を待って処理するように設定
	xml.async = false;

	// 送信先URL情報の設定
	var url = "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName = "/projects/" + projectId + "/wbsnodes";
	var queryParameter = "?limit=0";

	// 送信用URLを生成
	url = url + objectName + queryParameter;

	// リクエストの作成・送信
	request.open('GET', url, false, loginName, loginPassword);
	request.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	request.send();

	// リクエストのレスポンスの確認
	CheckHttpRequestResponse(request.status, request.responseXML);

	if (errorFlag == 0) {
		// リクエストの結果の取得
		xml.loadXML(request.responseText);

		// 取得した情報を配列に格納
		var arrayWBSNode = xml.getElementsByTagName("wbsnode");

		// 変数の初期化
		var nodeCollection = new Array();
		var count = 0;

		// WBS情報の各項目用配列に格納
		for (var i = 0; i < arrayWBSNode.length; i++) {
			// WBS情報の配列内に要素を追加する配列を設定
			nodeCollection[count] = new Array();

			//設定した配列内に要素を格納する
			nodeCollection[count].outlineNumber = arrayWBSNode[i].getElementsByTagName("outlineNumber")[0].text;
			nodeCollection[count].name = arrayWBSNode[i].getElementsByTagName("name")[0].text;
			nodeCollection[count].startDate = arrayWBSNode[i].getElementsByTagName("plannedStartDate")[0].text;
			nodeCollection[count].finishDate = arrayWBSNode[i].getElementsByTagName("plannedFinishDate")[0].text;
			nodeCollection[count].progress = arrayWBSNode[i].getElementsByTagName("progress")[0].text;

			if (arrayWBSNode[i].getElementsByTagName("kind")[0].text == "project") {
				nodeCollection[count].type = "プロジェクト";
			} else if (arrayWBSNode[i].getElementsByTagName("kind")[0].text == "taskPackage") {
				nodeCollection[count].type = "タスクパッケージ";
			} else if (arrayWBSNode[i].getElementsByTagName("kind")[0].text == "task") {
				nodeCollection[count].type = "タスク";
			} else {
				nodeCollection[count].type = "マイルストーン";
			}

			nodeCollection[count].outlineLevel = arrayWBSNode[i].getElementsByTagName("outlineLevel")[0].text;

			count++;
		}
	}
	// 設定した要素の一覧を返す
	return nodeCollection;
}

// =================================================================================================
// サーバの接続情報を記載した「SampleConfig.xml」ファイルの情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：「SampleConfig.xml」ファイルに記載されたサーバーマシン名とWebサイト名を取得します。
// =================================================================================================
function GetSampleConfig() {
	// オブジェクト作成
	var ConfigFile = new ActiveXObject("Microsoft.XMLDOM");

	// サーバの応答を待って処理するように設定
	ConfigFile.async = false;

	// SampleConfigファイルの読み込み
	ConfigFile.load("./../SampleConfig.xml");

	if (ConfigFile.getElementsByTagName("SampleConfig").length == 0) {
		errorFlag = 1;
		errorMessage = errorMessage + "SampleConfig.xmlが正常に読み込めません。";
	} else {
		// サーバーマシン名とWebサイト名の取得
		ServerName = ConfigFile.getElementsByTagName("ServerName")[0].text; // サーバーマシン名(ホスト名)
		TTFXWebServer = ConfigFile.getElementsByTagName("TTFXWebServer")[0].text; // Webサイト名

		if (ServerName == "") {
			errorFlag = 1;
			errorMessage = errorMessage + "SampleConfig.xmlのServerNameにホスト名が入力されいません。\n";
		}

		if (TTFXWebServer == "") {
			errorFlag = 1;
			errorMessage = errorMessage + "SampleConfig.xmlのTTFXWebServerにWebサイト名が入力されいません。";
		}
	}
}

// =================================================================================================
// ログイン時のURLからログイン情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：URL内に含まれるクエリパラメータからログイン名とパスワードを取得します。
// =================================================================================================
function GetLoginAccountData() {
	// URLのクエリパラメータの取得
	var loginData = location.search;

	if (loginData == "") {
		errorFlag = 1;
		errorMessage = errorMessage + "login.htmlよりツールを起動してください。";
	} else {
		loginData = loginData.substring(1,loginData.length);
		var arrayQueryParameter = loginData.split("&");

		// ログイン名とパスワードを取得
		loginName = arrayQueryParameter[0].split("=")[1];
		loginPassword = arrayQueryParameter[1].split("=")[1];

		if (loginName == "") {
			errorFlag = 1;
			errorMessage = errorMessage + "ログイン名を入力してください。";
		}
	}
}


// +++++ 【データ操作系】 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// =================================================================================================
// プロジェクト情報の一覧を画面に設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：プロジェクト情報の一覧を[プロジェクト情報一覧]画面のHTML内に登録します。
// 入力値　：projectCollection ･･･ 表示対象のプロジェクト情報
// =================================================================================================
function SetProjectDataList(projectCollection) {
	// 表示先の指定
	var projectListTable = document.getElementById("projectListTable");
	var tableBody = projectListTable.getElementsByTagName("tbody")[0];

	// フォントサイズ・列幅の指定
	var fontSize = 2;
	var widthRadioButton = 30;
	var widthProjectCode = 130;
	var widthProjectName = 150;
	var widthManagerName = 100;
	var widthSectionName = 100;
	var widthStartDate = 70;
	var widthFinishDate = 70;

	for (var i = 0; i < projectCollection.length; i++) {
		// ラジオボタンの作成
		var tdRadioButton = document.createElement("<input name='radioButtonSelectProject'>");
		tdRadioButton.getAttributeNode('type').nodeValue = "radio";
		tdRadioButton.getAttributeNode('value').nodeValue = projectCollection[i].id;

		// テキストノードの作成
		var tdTextProjectCode = document.createTextNode(projectCollection[i].code);
		var tdTextProjectName = document.createTextNode(projectCollection[i].name);
		var tdTextManagerName = document.createTextNode(projectCollection[i].managerName);
		var tdTextSectionName = document.createTextNode(projectCollection[i].sectionName);
		var tdTextStartDate = document.createTextNode(projectCollection[i].startDate);
		var tdTextFinishDate = document.createTextNode(projectCollection[i].finishDate);

		// font要素の作成
		var tdFontProjectCode = document.createElement("font");
		var tdFontProjectName = document.createElement("font");
		var tdFontManagerName = document.createElement("font");
		var tdFontSectionName = document.createElement("font");
		var tdFontStartDate = document.createElement("font");
		var tdFontFinishDate = document.createElement("font");

		// フォントサイズの設定
		tdFontProjectCode.getAttributeNode('size').nodeValue = fontSize;
		tdFontProjectName.getAttributeNode('size').nodeValue = fontSize;
		tdFontManagerName.getAttributeNode('size').nodeValue = fontSize;
		tdFontSectionName.getAttributeNode('size').nodeValue = fontSize;
		tdFontStartDate.getAttributeNode('size').nodeValue = fontSize;
		tdFontFinishDate.getAttributeNode('size').nodeValue = fontSize;

		// td要素の作成
		var tdElementRadioButton = document.createElement("td");
		var tdElementProjectCode = document.createElement("td");
		var tdElementProjectName = document.createElement("td");
		var tdElementManagerName = document.createElement("td");
		var tdElementSectionName = document.createElement("td");
		var tdElementStartDate = document.createElement("td");
		var tdElementFinishDate = document.createElement("td");

		// 列幅の設定
		tdElementRadioButton.getAttributeNode('width').nodeValue = widthRadioButton;
		tdElementProjectCode.getAttributeNode('width').nodeValue = widthProjectCode;
		tdElementProjectName.getAttributeNode('width').nodeValue = widthProjectName;
		tdElementManagerName.getAttributeNode('width').nodeValue = widthManagerName;
		tdElementSectionName.getAttributeNode('width').nodeValue = widthSectionName;
		tdElementStartDate.getAttributeNode('width').nodeValue = widthStartDate;
		tdElementFinishDate.getAttributeNode('width').nodeValue = widthFinishDate;

		// 表示位置の設定
		tdElementRadioButton.getAttributeNode('align').nodeValue = "center";
		tdElementStartDate.getAttributeNode('align').nodeValue = "center";
		tdElementFinishDate.getAttributeNode('align').nodeValue = "center";

		// tr要素の作成
		var trElement = document.createElement("tr");

		// font要素にテキストノードを追加
		tdFontProjectCode.appendChild(tdTextProjectCode);
		tdFontProjectName.appendChild(tdTextProjectName);
		tdFontManagerName.appendChild(tdTextManagerName);
		tdFontSectionName.appendChild(tdTextSectionName);
		tdFontStartDate.appendChild(tdTextStartDate);
		tdFontFinishDate.appendChild(tdTextFinishDate);

		// td要素にラジオボタンを追加
		tdElementRadioButton.appendChild(tdRadioButton);

		// td要素にfont要素を追加
		tdElementProjectCode.appendChild(tdFontProjectCode);
		tdElementProjectName.appendChild(tdFontProjectName);
		tdElementManagerName.appendChild(tdFontManagerName);
		tdElementSectionName.appendChild(tdFontSectionName);
		tdElementStartDate.appendChild(tdFontStartDate);
		tdElementFinishDate.appendChild(tdFontFinishDate);

		// tr要素にtd要素を追加
		trElement.appendChild(tdElementRadioButton); // ラジオボタン
		trElement.appendChild(tdElementProjectCode); // プロジェクトコード
		trElement.appendChild(tdElementProjectName); // プロジェクト名
		trElement.appendChild(tdElementManagerName); // マネージャ名
		trElement.appendChild(tdElementSectionName); // 組織名
		trElement.appendChild(tdElementStartDate);   // 開始日
		trElement.appendChild(tdElementFinishDate);  // 終了日

		// tbody要素にtr要素の追加
		tableBody.appendChild(trElement);
	}
}

// =================================================================================================
// WBS情報の一覧を画面に設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：WBS情報の一覧を[WBS情報表示]画面のHTML内に登録します。
// 入力値　：nodeCollection ･･･ 表示対象のWBS情報
// =================================================================================================
function SetWBSDataList(nodeCollection) {

	// 表示先の指定
	var WBSListTable = document.getElementById("wbsListTable");
	var tableBody = WBSListTable.getElementsByTagName("tbody")[0];

	// フォントサイズ・列幅の指定(ノード名の幅は可変長とする)
	var fontSize = 2;
	var widthOutlineNumber = 100;
	var widthStartDate = 70;
	var widthFinishDate = 70;
	var widthProgress = 50;
	var widthNodeType = 120;

	var calcProgress;

	for (var i = 0; i < nodeCollection.length; i++) {

		// テキストノードの作成
		var tdTextOutlineNumber = document.createTextNode(nodeCollection[i].outlineNumber);
		var tdTextNodeName = document.createTextNode(nodeCollection[i].name);

		// 日付が1753/01/01の場合はもともと空白であったため、"－"に置き換える
		// 開始日
		if (nodeCollection[i].startDate == "1753/01/01") {
			var tdTextStartDate = document.createTextNode("－");
		} else {
			var tdTextStartDate = document.createTextNode(nodeCollection[i].startDate);
		}

		// 終了日
		if (nodeCollection[i].finishDate == "1753/01/01") {
			var tdTextFinishDate = document.createTextNode("－");
		} else {
			var tdTextFinishDate = document.createTextNode(nodeCollection[i].finishDate);
		}

		// 進捗率を整数に丸める
		calcProgress = parseFloat(nodeCollection[i].progress);
		if (calcProgress > 0) {
			calcProgress = Math.round(calcProgress);
		}

		// 進捗率が255の場合は"N/A"を置き換えたものなので、文言を"255"から"N/A"に置き換える
		if (calcProgress == 255) {
			var tdTextProgress = document.createTextNode("N/A");
		} else {
			var tdTextProgress = document.createTextNode(calcProgress);
		}

		var tdTextNodeType = document.createTextNode(nodeCollection[i].type);

		// font要素の作成
		var tdFontOutlineNumber = document.createElement("font");
		var tdFontNodeName = document.createElement("font");
		var tdFontStartDate = document.createElement("font");
		var tdFontFinishDate = document.createElement("font");
		var tdFontProgress = document.createElement("font");
		var tdFontNodeType = document.createElement("font");

		// フォントサイズの設定
		tdFontOutlineNumber.getAttributeNode('size').nodeValue = fontSize;
		tdFontNodeName.getAttributeNode('size').nodeValue = fontSize;
		tdFontStartDate.getAttributeNode('size').nodeValue = fontSize;
		tdFontFinishDate.getAttributeNode('size').nodeValue = fontSize;
		tdFontProgress.getAttributeNode('size').nodeValue = fontSize;
		tdFontNodeType.getAttributeNode('size').nodeValue = fontSize;

		// td要素の作成
		var tdElementOutlineNumber = document.createElement("td");
		var tdElementNodeName = document.createElement("td");
		var tdElementStartDate = document.createElement("td");
		var tdElementFinishDate = document.createElement("td");
		var tdElementProgress = document.createElement("td");
		var tdElementNodeType = document.createElement("td");

		// 列幅の設定(ノード名の幅は可変長とする)
		tdElementOutlineNumber.getAttributeNode('width').nodeValue = widthOutlineNumber;
		tdElementStartDate.getAttributeNode('width').nodeValue = widthStartDate;
		tdElementFinishDate.getAttributeNode('width').nodeValue = widthFinishDate;
		tdElementProgress.getAttributeNode('width').nodeValue = widthProgress;
		tdElementNodeType.getAttributeNode('width').nodeValue = widthNodeType;

		// 表示位置の設定
		//WBSの階層に合わせてスペースを入れる
		//ルートノードと第1階層のノードは右揃えにするため、ルートノードだけインデントを設定しない
		if (nodeCollection[i].type != "プロジェクト") { // プロジェクトノード以外
			tdElementNodeName.style.paddingLeft = ((nodeCollection[i].outlineLevel-1)*20+2)+"px";
		}

		//値を中央揃えにする
		tdElementStartDate.getAttributeNode('align').nodeValue = "center";
		tdElementFinishDate.getAttributeNode('align').nodeValue = "center";

		//値を右端揃えにする
		tdElementProgress.getAttributeNode('align').nodeValue = "right";

		// ノード種別ごとのスタイルの設定
		if (nodeCollection[i].type == "プロジェクト") { // プロジェクトノード
			tdElementNodeName.style.fontWeight = "bold";
			tdElementNodeName.style.color = "navy";
		} else if (nodeCollection[i].type == "タスクパッケージ") { // タスクパッケージノード
			tdElementNodeName.style.fontWeight = "bold";
		} else if (nodeCollection[i].type == "タスク") { // タスクノード
		} else { // マイルストーンノード
			tdElementNodeName.style.color = "gray";
			tdElementNodeName.style.fontStyle = "Italic";
		}

		// tr要素の作成
		var trElement = document.createElement("tr");

		//プロジェクトノードについては配色を変更する
		if (nodeCollection[i].type == "プロジェクト"){ // プロジェクトノード
			trElement.style.backgroundColor = "sandybrown";
		}

		// font要素にテキストノードを追加
		tdFontOutlineNumber.appendChild(tdTextOutlineNumber);
		tdFontNodeName.appendChild(tdTextNodeName);
		tdFontStartDate.appendChild(tdTextStartDate);
		tdFontFinishDate.appendChild(tdTextFinishDate);
		tdFontProgress.appendChild(tdTextProgress);
		tdFontNodeType.appendChild(tdTextNodeType);

		// td要素にfont要素を追加
		tdElementOutlineNumber.appendChild(tdFontOutlineNumber);
		tdElementNodeName.appendChild(tdFontNodeName);
		tdElementStartDate.appendChild(tdFontStartDate);
		tdElementFinishDate.appendChild(tdFontFinishDate);
		tdElementProgress.appendChild(tdFontProgress);
		tdElementNodeType.appendChild(tdFontNodeType);
	
		// tr要素にtd要素を追加
		trElement.appendChild(tdElementOutlineNumber); // アウトライン番号
		trElement.appendChild(tdElementNodeName);      // ノード名
		trElement.appendChild(tdElementStartDate);     // 開始日
		trElement.appendChild(tdElementFinishDate);    // 終了日
		trElement.appendChild(tdElementProgress);      // 進捗率
		trElement.appendChild(tdElementNodeType);      // ノード種別

		// tbody要素にtr要素の追加
		tableBody.appendChild(trElement);
	}
}

// =================================================================================================
// [プロジェクト情報一覧]画面および[WBS情報表示]に表示した一覧情報を削除する
// -------------------------------------------------------------------------------------------------
// 概要　　：表示を切り替えるたびにデータが追加されるため、本メソッドでデータが無い状態にします。
// =================================================================================================
function DeleteDataList() {
	// 削除箇所の指定
	if (document.getElementById("projectListView").style.display == "inline"){
		var targetTable = document.getElementById("projectListTable");
	} else {
		var targetTable = document.getElementById("wbsListTable");
	}

	// tbody要素の情報を削除
	var tableBody = targetTable.getElementsByTagName("tbody")[0];
	var arrayTr = tableBody.getElementsByTagName("tr");
	var arrayTrLength = arrayTr.length;

	for (var y = 0; y < arrayTrLength; y++) {
		// tr要素の削除
		tableBody.removeChild(arrayTr[0]);
	}
}

// =================================================================================================
// リクエストに対するサーバからのレスポンスを確認する
// -------------------------------------------------------------------------------------------------
// 概要　　：HTTPリクエストのレスポンスに応じて、エラーメッセージを設定します。
// 入力値　：responseCode ･･･ レスポンスコード
// 　　　　　responseXML  ･･･ XML形式のレスポンス
// =================================================================================================
function CheckHttpRequestResponse(responseCode, responseXML) {
	switch (responseCode) {
		case 200:
			// 正常系の処理であり、エラーではない
			break;
		case 400:
			errorFlag = 1;
			errorMessage = errorMessage + "パラメータやリクエストに不備があります。\n";
			errorMessage = errorMessage + responseXML.getElementsByTagName("Message")[0].text;
			break;
		case 401:
			errorFlag = 1;
			errorMessage = errorMessage + "認証に失敗しました。\n";
			errorMessage = errorMessage + "ログイン名またはパスワードに誤りがあります。";
			break;
		case 404:
			errorFlag = 1;
			errorMessage = errorMessage + "指定したソース(URI)が存在しません。";
			break;
		case 405:
			errorFlag = 1;
			errorMessage = errorMessage + "指定したHTTPメソッドが使用できません。";
			break;
		case 411:
			errorFlag = 1;
			errorMessage = errorMessage + "HTTP リクエストヘッダにContent-Lengthが指定されていません。";
			break;
		case 500:
			errorFlag = 1;
			errorMessage = errorMessage + "サーバーでエラーが発生しました。";
			break;
		default:
			errorFlag = 1;
			errorMessage = errorMessage + "エラーが発生しました。\n";
			errorMessage = errorMessage + "SampleConfig.xmlに不備がある可能性があります。";
			break;
	}
}


// +++++ 【画面表示系】 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// =================================================================================================
// [プロジェクト情報一覧]画面を表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：プロジェクト情報を取得し、[プロジェクト情報一覧]画面を表示します。
// =================================================================================================
function DisplayProjectListView() {
	// 変数の初期化
	errorFlag = 0;
	errorMessage = "";

	// 接続先情報の確認
	if (errorFlag == 0) {
		GetSampleConfig();
	}

	// ログイン情報の確認
	if (errorFlag == 0) {
		GetLoginAccountData();
	}

	// プロジェクト情報一覧の取得
	if (errorFlag == 0) {
		var projectCollection = GetProjectDataList();
	}

	if (errorFlag == 0) {
		// プロジェクト情報一覧なしのエラー処理
		if (projectCollection.length == 0) {
			errorFlag = 1;
			errorMessage = "編集可能なプロジェクトがありません。";
		}
	}

	// プロジェクト情報一覧の表示
	if (errorFlag == 0) {

		// 開始日の降順を判定するソート関数を定義
		var sortFunction = function(firstElement, secondElement) {
			// 2つ目の要素が1つ目の要素より大きい場合に正の数を返す
			return Date.parse(secondElement.startDate) - Date.parse(firstElement.startDate);
		}

		// 2つ目の要素が1つ目の要素より大きい場合は要素を入れ替えることを繰り返す
		projectCollection.sort(sortFunction);

		// [WBS情報一覧]画面の情報削除
		DeleteDataList();

		// プロジェクト情報の一覧を画面の表示箇所に設定する
		SetProjectDataList(projectCollection);

		// [プロジェクト情報一覧]画面への切り替え
		SwitchView("projectListView");
	}

	// エラーの表示
	if (errorFlag == 1) {
		// ログイン画面に戻る
		window.location.href = "./login.html";
		alert(errorMessage);
	}
}

// =================================================================================================
// [WBS情報表示]画面を表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：選択されているプロジェクトを検索し、[WBS情報表示]画面にWBS情報を表示します。
// =================================================================================================
function DisplayWBSListView() {
	// 変数の初期化
	errorFlag = 0;
	errorMessage = "";

	// 検索対象の指定
	var projectListTable = document.getElementById("projectListTable");
	var tableBody = projectListTable.getElementsByTagName("tbody")[0];
	var radioButtonList = tableBody.getElementsByTagName('input');

	// 選択プロジェクトのプロジェクトID用変数の初期化
	var selectProjectId = -1;

	// 選択プロジェクトの検索
	for (var i = 0; i < radioButtonList.length; i++) {
		if (radioButtonList[i].checked) {
			// 選択プロジェクトのプロジェクトIDの取得
			selectProjectId = radioButtonList[i].value;
			break;
		}
	}

	// 選択プロジェクトなしのエラー処理
	if (selectProjectId == -1) {
		errorFlag = 1;
		errorMessage = errorMessage + "プロジェクトを選択してください。";
	}

	// エラーでない場合はWBS情報の表示に切り替える
	if (errorFlag == 0) {

		// [プロジェクト情報一覧]画面の情報削除
		DeleteDataList();

		// WBS情報を取得する
		var nodeCollection = GetWBSDataList(selectProjectId);

		// WBS情報の一覧を画面の表示箇所に設定する
		SetWBSDataList(nodeCollection);

		// [WBS情報表示]画面への切り替え
		SwitchView("wbsListView");
	}

	// エラーの表示
	if (errorFlag == 1) {
		alert(errorMessage);
	}
}

// =================================================================================================
// [プロジェクト情報一覧]画面と[WBS情報表示]画面の表示を切り替える
// -------------------------------------------------------------------------------------------------
// 概要　　：入力値に指定した画面の方を表示する。
// 入力値　：viewName ･･･ 表示対象とする画面の名称
// =================================================================================================
function SwitchView(viewName) {

	// プロジェクト一覧の画面を有効にする
	if (viewName == "projectListView") {
		document.getElementById("wbsListView").style.display = "none";
		document.getElementById("projectListView").style.display = "inline";

	// WBS情報の画面を有効にする
	} else if (viewName == "wbsListView") {
		document.getElementById("wbsListView").style.display = "inline";
		document.getElementById("projectListView").style.display = "none";
	}
}
