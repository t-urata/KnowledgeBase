
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □                    「プロジェクト情報表示ツール」サブプログラム（制御系）                    □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「フィルタ条件」や「出力した情報の表示」など                                    □
// □  ［プロジェクト情報表示ツール］のインターフェイス操作の制御系の処理を実施します。            □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  ClickFilterCheckBox()       ・・・ フィルタ条件のチェックボックスクリック時の制御           □
// □  ClickQuickFilterCheckBox()  ・・・ クイックフィルタのチェックボックスクリック時の制御       □
// □  ClickSort1CheckBox()        ・・・ ソート条件のチェックボックスクリック時の制御             □
// □  ClickOutputRadioButton()    ・・・ CSVファイル出力のラジオボタンのクリック時の制御          □
// □  ChangeSettingView()         ・・・ 設定画面表示切替の制御                                   □
// □  ChangeProjectDataListView() ・・・ 出力結果画面表示切替の制御                               □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// フィルタ条件のチェックボックスクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：フィルタ条件の［プロジェクト名］・［マネージャ名］・［組織名］の
//           チェックボックスをクリック時の動作を制御します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickFilterCheckBox() {
// ［プロジェクト名］・［マネージャ名］・［組織名］のチェックの状態の確認
	if (document.setting.chboxProjectName.checked
		|| document.setting.chboxManagerName.checked
		|| document.setting.chboxSectionName.checked) {

	// テキストボックスを有効にする
		document.setting.filterProjectName.disabled	= false;
		document.setting.filterManagerName.disabled	= false;
		document.setting.filterSectionName.disabled	= false;

	// チェックを外す
		document.setting.chboxQuickFilter.checked	= false;

	// セレクトボックスを無効にする
		document.setting.selectQuickFilter.disabled	= true;

	} else {
	// セレクトボックスを有効にする
		document.setting.selectQuickFilter.disabled	= false;
	}
}


// =================================================================================================
// クイックフィルタのチェックボックスクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：フィルタ条件の［クイックフィルタ］のチェックボックスをクリック時の動作を制御します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickQuickFilterCheckBox() {
// ［クイックフィルタ］のチェックの状態の確認
	if (document.setting.chboxQuickFilter.checked) {
	// チェックを外す
		document.setting.chboxProjectName.checked	= false;
		document.setting.chboxManagerName.checked	= false;
		document.setting.chboxSectionName.checked	= false;

	// テキストボックスを無効にする
		document.setting.filterProjectName.disabled	= true;
		document.setting.filterManagerName.disabled	= true;
		document.setting.filterSectionName.disabled	= true;

	// セレクトボックスを有効にする
		document.setting.selectQuickFilter.disabled	= false;

	} else {
	// テキストボックスを有効にする
		document.setting.filterProjectName.disabled	= false;
		document.setting.filterManagerName.disabled	= false;
		document.setting.filterSectionName.disabled	= false;
	}
}


// =================================================================================================
// ソート条件のチェックボックスクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：ソート条件の優先度が1番目のチェックボックスのクリック時の動作を制御します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickSort1CheckBox() {
// チェック状態の確認
	if (document.setting.sort1.checked) {
	// 優先度が2番目の条件設定を変更可能な状態にする
		document.setting.sort2.disabled			= false;
		document.setting.sortTarget2.disabled	= false;
		document.setting.sortType2.disabled		= false;
	} else {
	// 優先度が2番目の条件設定を変更不可能な状態にする
		document.setting.sort2.checked			= false;
		document.setting.sort2.disabled			= true;
		document.setting.sortTarget2.disabled	= true;
		document.setting.sortType2.disabled		= true;
	}
}


// =================================================================================================
// CSVファイル出力のラジオボタンのクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：CSVファイル出力のラジオボタンのクリック時の動作を制御します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickOutputRadioButton() {
// ラジオボタンの状態の確認
	if (document.setting.outputSwitch[0].checked) {
		document.setting.output.disabled = false;
	} else {
		document.setting.output.disabled = true;
	}
}


// =================================================================================================
// 設定画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面を非表示にし、設定画面に表示を切り替えます。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSettingView() {
	document.getElementById("settingView").style.display	= "block";
	document.getElementById("resultView").style.display		= "none";
}


// =================================================================================================
// 出力結果画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面を表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeProjectDataListView() {
	document.getElementById("resultView").style.display = "block";
}
