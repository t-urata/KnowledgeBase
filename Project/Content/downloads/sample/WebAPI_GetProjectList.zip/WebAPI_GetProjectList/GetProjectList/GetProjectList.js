
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □                    「プロジェクト情報表示ツール」メインプログラム（情報取得系）              □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「プロジェクト情報の一覧の取得」や「ソート」など                                □
// □  ［プロジェクト情報表示ツール］で行う情報取得系の処理を実施します。                          □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  SetDefaultSettingView()           ・・・ 条件設定画面の初期値を設定する                     □
// □  GetLoginAccountData()             ・・・ ログインアカウントの情報を取得する                 □
// □  GetProjectDataAndOutputDataList() ・・・ プロジェクト情報の一覧を取得し、出力する           □
// □  GetFilterAndSortSetting()         ・・・ フィルタとソートの条件設定を取得する               □
// □  GetProjectDataList()              ・・・ プロジェクト情報の一覧を取得する                   □
// □  GetCrossSortData()                ・・・ 指定条件にてソート（クロスソート）を実施する       □
// □  DisplayProjectDataList()          ・・・ プロジェクト情報の一覧を画面に表示する             □
// □  DisplayDataListHeader()           ・・・ プロジェクト情報の項目名（列名）を画面に表示する   □
// □  ReadSampleConfig()                ・・・ 「Sample.config」ファイルの情報を読み込む          □
// □  ReadLoginAccountData()            ・・・ ログイン情報を読み込む                             □
// □  CheckHttpRequestResponse()        ・・・ HTTPリクエストのレスポンス情報の確認する           □
// □  DeleteDisplayData()               ・・・ 画面上に表示された情報を削除する                   □
// □  OutputCSVFile()                   ・・・ 取得した情報をCSVファイルに出力する                □
// □  OffsetValue()                     ・・・ プログラム内の変数を初期化する                     □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// 内部共通変数の宣言
// -------------------------------------------------------------------------------------------------
// 概要　　：「プロジェクト情報表示ツール」で利用する共通の変数を宣言します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
// ログイン情報
	var loginName;					// ログイン名
	var loginPass;					// パスワード

// 接続先情報
	var ServerName;					// サーバーマシン名（ホスト名）
	var TTFXWebServer;				// Web サイト名

// ログインアカウントの情報
	var loginAccountId;				// ログインアカウントのアカウントID
	var loginAccountName;			// ログインアカウントのアカウント名
	var loginAccountSectionId;		// ログインアカウントの所属組織のID

// 条件設定情報
	var filterProjectName;			// フィルタするプロジェクト名
	var filterManagerName;			// フィルタするマネージャ名
	var filterSectionName;			// フィルタする組織名
	var selectFinished;				// 終了済みプロジェクトを含めるか
	var selectQuickFilter;			// クイックフィルタの選択値
	var sortTarget1;				// 1番目のソート対象の配列
	var sortTarget2;				// 2番目のソート対象の配列
	var sortType1;					// 1番目のソート対象のソート順
	var sortType2;					// 2番目のソート対象ののソート順

// 集計用配列の宣言
	var arrayProjectId;				// プロジェクトID
	var arrayProjectCode;			// プロジェクトコード
	var arrayProjectName;			// プロジェクト名
	var arraySectionName;			// 組織名
	var arrayManagerName;			// マネージャ名
	var arrayStartDate;				// 開始日
	var arrayFinishDate;			// 終了日
	var arrayIsFinished;			// ステータス

// エラー処理用変数
	var error_MSG;					// エラーメッセージ
	var error_Flag;					// エラーフラグ（0:エラー無し、1：エラー有り）

// 出力結果画面の列幅およびフォントサイズの設定
	var widthNo				= 20;	// No.列
	var widthProjectCode	= 120;	// プロジェクトコード列
	var widthProjectName	= 120;	// プロジェクト名列
	var widthSectionName	= 100;	// 日付列
	var widthManagerName	= 90;	// 開始時刻列
	var widthStartDate		= 70;	// 終了時刻列
	var widthFinishDate		= 70;	// 実績工数列
	var widthIsFinished		= 60;	// 実績工数列
	var resultFontSize		= 2;	// フォントサイズ


// =================================================================================================
// 条件設定画面の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：ログインアカウントの情報を取得し、条件設定画面の初期値を設定します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultSettingView() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 接続先情報の確認
	if (error_Flag == 0) {
		ReadSampleConfig();
	}

// ログイン情報の確認
	if (error_Flag == 0) {
		ReadLoginAccountData();
	}

// ログインアカウントの情報取得
	if (error_Flag == 0) {
		GetLoginAccountData();
	}

	if (error_Flag == 0) {
	// 設定画面の表示
		ChangeSettingView();

	// マネージャ名にログイン中のアカウント名を設定
		document.getElementById("filterManagerName").value = loginAccountName;

	// 条件設定に応じて各フォームの状態を最適化
		ClickFilterCheckBox();
		ClickQuickFilterCheckBox();
		ClickSort1CheckBox();
		ClickOutputRadioButton();
	}

// エラーの表示
	if (error_Flag == 1) {
	// ログイン画面に戻る
		window.location.href = "./login.html";
		alert(error_MSG);
	}
}


// =================================================================================================
// ログインアカウントの情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIでログインアカウントのアカウント情報を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetLoginAccountData() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// 送信先URLの設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/accounts";
	var queryParameter	= "?onlyLoginAccount=TRUE";	// ログインアカウントの情報のみ取得

// URLの生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

	// ログインアカウントの情報の取得
		loginAccountId			= xml.getElementsByTagName("id")[0].text;
		loginAccountName		= xml.getElementsByTagName("name")[0].text;
		loginAccountSectionId	= xml.getElementsByTagName("sectionId")[0].text;
	}
}


// =================================================================================================
// プロジェクト情報の一覧を取得し、出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：条件に応じてプロジェクト情報を取得・ソートし、出力します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetProjectDataAndOutputDataList() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 出力画面の初期化
	DeleteDisplayData();

// 設定条件の取得
	GetFilterAndSortSetting();

// プロジェクト一覧の取得
	GetProjectDataList();

	if (arrayProjectId.length == 0) {
		error_Flag	= 1;
		error_MSG	= "取得できるプロジェクトがありません。";
	}

// ソート
	if (error_Flag == 0) {
		var input_Array1;
		var input_Array2;

	// ソートする配列の取得(第1条件)
		switch (sortTarget1) {
			case "sortProjectCode":
				input_Array1 = arrayProjectCode;
				break;
			case "sortProjectName":
				input_Array1 = arrayProjectName;
				break;
			case "sortSectionName":
				input_Array1 = arraySectionName;
				break;
			case "sortManagerName":
				input_Array1 = arrayManagerName;
				break;
			case "sortStartDate":
				input_Array1 = arrayStartDate;
				break;
			case "sortFinishDate":
				input_Array1 = arrayFinishDate;
				break;
			case "sortIsFinished":
				input_Array1 = arrayIsFinished;
				break;
		}

	// ソートする配列の取得(第2条件)
		switch (sortTarget2) {
			case "sortProjectCode":
				input_Array2 = arrayProjectCode;
				break;
			case "sortProjectName":
				input_Array2 = arrayProjectName;
				break;
			case "sortSectionName":
				input_Array2 = arraySectionName;
				break;
			case "sortManagerName":
				input_Array2 = arrayManagerName;
				break;
			case "sortStartDate":
				input_Array2 = arrayStartDate;
				break;
			case "sortFinishDate":
				input_Array2 = arrayFinishDate;
				break;
			case "sortIsFinished":
				input_Array2 = arrayIsFinished;
				break;
		}

		var resultSort = GetCrossSortData(input_Array1, input_Array2, sortType1, sortType2);
	}

// 外部ファイルおよび画面表示の出力
	if (error_Flag == 0) {
	// 外部ファイル出力
		if (document.setting.outputSwitch[0].checked) {
			OutputCSVFile(resultSort);
		}

	// 出力結果画面の表示
		DisplayDataListHeader();
		DisplayProjectDataList(resultSort);
		ChangeProjectDataListView();
	}

// エラーの表示
	if (error_Flag == 1) {
		alert(error_MSG);
	}

// 変数初期化
	OffsetValue();
}


// =================================================================================================
// フィルタとソートの条件設定を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：［フィルタ条件］と［ソート条件］の設定情報を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetFilterAndSortSetting() {
// 初期化
	filterProjectName	= "";
	filterManagerName	= "";
	filterSectionName	= "";
	selectFinished		= "";
	selectQuickFilter	= "";
	sortTarget1			= "sortProjectCode";
	sortTarget2			= "";
	sortType1			= 0;
	sortType2			= 0;

// 各フィルタ条件の取得
	if (document.setting.chboxProjectName.checked) {
		filterProjectName = document.getElementById("filterProjectName").value;
	}

	if (document.setting.chboxManagerName.checked) {
		filterManagerName = document.getElementById("filterManagerName").value;
	}

	if (document.setting.chboxSectionName.checked) {
		filterSectionName = document.getElementById("filterSectionName").value;
	}

	if (document.setting.chboxFinished.checked) {
		selectFinished = document.setting.selectFinished.value;
	}

	if (document.setting.chboxQuickFilter.checked) {
		selectQuickFilter = document.setting.selectQuickFilter.value;
	}

// ソート条件の取得
	if (document.setting.sort1.checked) {
		sortTarget1	= document.setting.sortTarget1.value;
		sortType1	= Number(document.setting.sortType1.value);
	}

	if (document.setting.sort2.checked) {
		sortTarget2	= document.setting.sortTarget2.value;
		sortType2	= Number(document.setting.sortType2.value);
	}
}


// =================================================================================================
// プロジェクト情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIでプロジェクト情報の一覧を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetProjectDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/projects";
	var queryParameter	= "?limit=0&fields=isFinished";	// 取得データ数の上限を無制限に指定,完了フラグを追加で取得

// フィルタ条件をクエリパラメータに設定
	if (filterProjectName != "") {
		queryParameter = queryParameter + "&projectName=" + escape(filterProjectName);
	}

	if (filterManagerName != "") {
		queryParameter = queryParameter + "&managerName=" + escape(filterManagerName);
	}

	if (filterSectionName != "") {
		queryParameter = queryParameter + "&sectionName=" + escape(filterSectionName);
	}

	queryParameter = queryParameter + "&includeFinished=" + selectFinished;

	if (selectQuickFilter == "manager") {
		queryParameter = queryParameter + "&managerIds=" + loginAccountId;
	} else if (selectQuickFilter == "section") {
		queryParameter = queryParameter + "&sectionIds=" + loginAccountSectionId;
	}

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayProject = xml.getElementsByTagName("project");

// 変数の初期化
	arrayProjectId		= new Array();
	arrayProjectCode	= new Array();
	arrayProjectName	= new Array();
	arraySectionName	= new Array();
	arrayManagerName	= new Array();
	arrayStartDate		= new Array();
	arrayFinishDate		= new Array();
	arrayIsFinished		= new Array();

// 取得情報を各項目用配列に再格納
	for(var i = 0; i < arrayProject.length; i++) {
		arrayProjectId[i]									= arrayProject[i].getElementsByTagName("id")[0].text;
		arrayProjectCode["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("code")[0].text;
		arrayProjectName["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("name")[0].text;
		arraySectionName["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("sectionName")[0].text;
		arrayManagerName["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("managerName")[0].text;
		arrayStartDate["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("plannedStartDate")[0].text;
		arrayFinishDate["ProjectId_" + arrayProjectId[i]]	= arrayProject[i].getElementsByTagName("plannedFinishDate")[0].text;

		if (arrayProject[i].getElementsByTagName("isFinished")[0].text == "True") {
			arrayIsFinished["ProjectId_" + arrayProjectId[i]] = "終了済み";
		} else {
			arrayIsFinished["ProjectId_" + arrayProjectId[i]] = "稼働中";
		}
	}
}


// =================================================================================================
// 指定条件にてソート（クロスソート）を実施する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定条件に応じて、ソートします。
// 入力値　：input_Array1 ･･･ 1番目のキー
//           input_Array2 ･･･ 2番目のキー
//           ST1          ･･･ 1番目のキーの順序（0：昇順,1：降順）
//           ST2          ･･･ 2番目のキーの順序（0：昇順,1：降順）
// 戻り値　：ソート後のキー配列
// =================================================================================================
function GetCrossSortData(input_Array1, input_Array2, ST1, ST2) {
// 初期化
	var DInput_Array1	=	new Array();
	var DInput_Array2	=	new Array();
	var secondKey_Array	=	new Array();
	var masterKey_Array	=	new Array();

// キー＋プロジェクトIDの配列に変更
	var count = 0;
	for (i in input_Array1) {
		DInput_Array1[count] = input_Array1[i].toUpperCase() + "|" + i;
		count++;
	}

	count = 0;
	for (i in input_Array2) {
		DInput_Array2[count] = input_Array2[i].toUpperCase() + "|" + i;
		count++;
	}

// 1番目のキーの要素ソートする
	switch (ST1) {
		case 0:
			DInput_Array1.sort();
			break;
		case 1:
			DInput_Array1.sort();
			DInput_Array1.reverse();
			break;
	}

	var masterCount = 0;
	if (DInput_Array2.length == 0) {
	// 1番目のキーのみの場合
		for (var i = 0; i < DInput_Array1.length; i++) {
			masterKey_Array[masterCount] = DInput_Array1[i].split("|ProjectId_")[1];
			masterCount++;
		}
	} else {
	// 2番目のキーがある場合
	// 優先キー要素が重複しない2次元配列を作成
		var first_KeyCount = 0;		// 第1優先キーのカウンタ
		var second_KeyCount;		// 第2キーのカウンタ
		var second_Element;			// 第2キーの要素用配列

		for (j in DInput_Array1) {
		// 初回実行時
			if (j == 0) {
				second_Element = DInput_Array1[j].split("|ProjectId_")[0];
				secondKey_Array[first_KeyCount] = new Array();
				second_KeyCount = 0;
			} else if (second_Element != DInput_Array1[j].split("|ProjectId_")[0]) {
				first_KeyCount++;

				second_Element = DInput_Array1[j].split("|ProjectId_")[0];
				secondKey_Array[first_KeyCount] = new Array();

				second_KeyCount = 0;
			} else {
				second_KeyCount++;
			}

			for (k in DInput_Array2) {
			// 第2キーの要素の取得
				if (DInput_Array1[j].split("|ProjectId_")[1] == DInput_Array2[k].split("|ProjectId_")[1]) {
					secondKey_Array[first_KeyCount][second_KeyCount] = DInput_Array2[k];
				}
			}
		}

		// 1次元目の要素ごとに2次元目の要素をソートする
		for (var i = 0; i < secondKey_Array.length; i++) {
			var dummy = secondKey_Array[i];
			switch (ST2) {
				case 0:
					dummy.sort();
					break;
				case 1:
					dummy.sort();
					dummy.reverse();
					break;
			}

			// プロジェクトIDを取り出し、ソートされたプロジェクトIDの配列を作成する
			for (var j = 0; j < secondKey_Array[i].length; j++) {
				masterKey_Array[masterCount] = dummy[j].split("|ProjectId_")[1];
				masterCount++;
			}
		}
	}

	return masterKey_Array;
}


// =================================================================================================
// プロジェクト情報の一覧を画面に表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：プロジェクト情報の一覧を［プロジェクト一覧］に表示します。
// 入力値　：outputProjectIdList ･･･ 出力対象のプロジェクトID一覧
// 戻り値　：無
// =================================================================================================
function DisplayProjectDataList(outputProjectIdList) {
// 表示先の指定
	var resultTable		= document.getElementById("resultTable");
	var tableBody		= resultTable.getElementsByTagName("tbody")[0];
	var resultFontSize	= 2;

	for (var i = 0; i < outputProjectIdList.length; i++) {
	// テキストノードの作成
		var tdTextNo			= document.createTextNode(i + 1);
		var tdTextProjectCode	= document.createTextNode(arrayProjectCode["ProjectId_" + outputProjectIdList[i]]);
		var tdTextProjectName	= document.createTextNode(arrayProjectName["ProjectId_" + outputProjectIdList[i]]);
		var tdTextSectionName	= document.createTextNode(arraySectionName["ProjectId_" + outputProjectIdList[i]]);
		var tdTextManagerName	= document.createTextNode(arrayManagerName["ProjectId_" + outputProjectIdList[i]]);
		var tdTextStartDate		= document.createTextNode(arrayStartDate["ProjectId_" + outputProjectIdList[i]]);
		var tdTextFinishDate	= document.createTextNode(arrayFinishDate["ProjectId_" + outputProjectIdList[i]]);
		var tdTextIsFinished	= document.createTextNode(arrayIsFinished["ProjectId_" + outputProjectIdList[i]]);

	// fontタグの作成
		var tdFontNo			= document.createElement("font");
		var tdFontProjectCode	= document.createElement("font");
		var tdFontProjectName	= document.createElement("font");
		var tdFontSectionName	= document.createElement("font");
		var tdFontManagerName	= document.createElement("font");
		var tdFontStartDate		= document.createElement("font");
		var tdFontFinishDate	= document.createElement("font");
		var tdFontIsFinished	= document.createElement("font");

	// フォントサイズの設定
		tdFontNo.getAttributeNode('size').nodeValue				= resultFontSize;
		tdFontProjectCode.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontProjectName.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontSectionName.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontManagerName.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontStartDate.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontFinishDate.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontIsFinished.getAttributeNode('size').nodeValue		= resultFontSize;

	// tdタグの作成
		var tdElementNo				= document.createElement("td");
		var tdElementProjectCode	= document.createElement("td");
		var tdElementProjectName	= document.createElement("td");
		var tdElementSectionName	= document.createElement("td");
		var tdElementManagerName	= document.createElement("td");
		var tdElementStartDate		= document.createElement("td");
		var tdElementFinishDate		= document.createElement("td");
		var tdElementIsFinished		= document.createElement("td");

	// 列幅の設定
		tdElementNo.getAttributeNode('width').nodeValue				= widthNo;
		tdElementProjectCode.getAttributeNode('width').nodeValue	= widthProjectCode;
		tdElementProjectName.getAttributeNode('width').nodeValue	= widthProjectName;
		tdElementSectionName.getAttributeNode('width').nodeValue	= widthSectionName;
		tdElementManagerName.getAttributeNode('width').nodeValue	= widthManagerName;
		tdElementStartDate.getAttributeNode('width').nodeValue		= widthStartDate;
		tdElementFinishDate.getAttributeNode('width').nodeValue		= widthFinishDate;
		tdElementIsFinished.getAttributeNode('width').nodeValue		= widthIsFinished;

	// 表示位置の設定
		tdElementStartDate.getAttributeNode('align').nodeValue	= "center";
		tdElementFinishDate.getAttributeNode('align').nodeValue	= "center";
		tdElementIsFinished.getAttributeNode('align').nodeValue	= "center";

	// trタグの作成
		var trElement = document.createElement("tr");

	// fontタグにテキストノードを追加
		tdFontNo.appendChild(tdTextNo);
		tdFontProjectCode.appendChild(tdTextProjectCode);
		tdFontProjectName.appendChild(tdTextProjectName);
		tdFontSectionName.appendChild(tdTextSectionName);
		tdFontManagerName.appendChild(tdTextManagerName);
		tdFontStartDate.appendChild(tdTextStartDate);
		tdFontFinishDate.appendChild(tdTextFinishDate);
		tdFontIsFinished.appendChild(tdTextIsFinished);

	// tdタグにfontタグを追加
		tdElementNo.appendChild(tdFontNo);
		tdElementProjectCode.appendChild(tdFontProjectCode);
		tdElementProjectName.appendChild(tdFontProjectName);
		tdElementSectionName.appendChild(tdFontSectionName);
		tdElementManagerName.appendChild(tdFontManagerName);
		tdElementStartDate.appendChild(tdFontStartDate);
		tdElementFinishDate.appendChild(tdFontFinishDate);
		tdElementIsFinished.appendChild(tdFontIsFinished);
		
	// trタグ内にtdタグ内容を追加
		trElement.appendChild(tdElementNo);				// No.
		trElement.appendChild(tdElementProjectCode);	// プロジェクトコード
		trElement.appendChild(tdElementProjectName);	// プロジェクト名
		trElement.appendChild(tdElementSectionName);	// 組織名
		trElement.appendChild(tdElementManagerName);	// マネージャ名
		trElement.appendChild(tdElementStartDate);		// 開始日
		trElement.appendChild(tdElementFinishDate);		// 終了日
		trElement.appendChild(tdElementIsFinished);		// ステータス

	// tbodyタグ内にtrタグの内容を追加
		tableBody.appendChild(trElement);
	}
}


// =================================================================================================
// プロジェクト情報の項目名（列名）を画面に表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：プロジェクト情報の項目名（列名）を［プロジェクト一覧］に表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function DisplayDataListHeader() {
// 表示先の指定
	var resultTable	= document.getElementById("resultTable");
	var tableHead	= resultTable.getElementsByTagName("thead")[0];

// テキストノードの作成
	var tdTextNo			= document.createTextNode("No.");
	var tdTextProjectCode	= document.createTextNode("プロジェクトコード");
	var tdTextProjectName	= document.createTextNode("プロジェクト名");
	var tdTextSectionName	= document.createTextNode("組織名");
	var tdTextManagerName	= document.createTextNode("マネージャ名");
	var tdTextStartDate		= document.createTextNode("開始日");
	var tdTextFinishDate	= document.createTextNode("終了日");
	var tdTextIsFinished	= document.createTextNode("ステータス");

// fontタグの作成
	var tdFontNo			= document.createElement("font");
	var tdFontProjectCode	= document.createElement("font");
	var tdFontProjectName	= document.createElement("font");
	var tdFontSectionName	= document.createElement("font");
	var tdFontManagerName	= document.createElement("font");
	var tdFontStartDate		= document.createElement("font");
	var tdFontFinishDate	= document.createElement("font");
	var tdFontIsFinished	= document.createElement("font");

// フォントサイズの設定
	tdFontNo.getAttributeNode('size').nodeValue				= resultFontSize;
	tdFontProjectCode.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontProjectName.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontSectionName.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontManagerName.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontStartDate.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontFinishDate.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontIsFinished.getAttributeNode('size').nodeValue		= resultFontSize;

// td要素の作成
	var tdElementNo     		= document.createElement("td");
	var tdElementProjectCode	= document.createElement("td");
	var tdElementProjectName	= document.createElement("td");
	var tdElementSectionName	= document.createElement("td");
	var tdElementManagerName	= document.createElement("td");
	var tdElementStartDate		= document.createElement("td");
	var tdElementFinishDate		= document.createElement("td");
	var tdElementIsFinished		= document.createElement("td");

// テーブルの幅の設定
	var widthTable = widthNo + widthProjectCode + widthProjectName + widthSectionName + widthManagerName
						+ widthStartDate + widthFinishDate + widthIsFinished + 66;
	resultTable.getAttributeNode('width').nodeValue = widthTable;

// 列幅の設定
	tdElementNo.getAttributeNode('width').nodeValue				= widthNo;
	tdElementProjectCode.getAttributeNode('width').nodeValue	= widthProjectCode;
	tdElementProjectName.getAttributeNode('width').nodeValue	= widthProjectName;
	tdElementSectionName.getAttributeNode('width').nodeValue	= widthSectionName;
	tdElementManagerName.getAttributeNode('width').nodeValue	= widthManagerName;
	tdElementStartDate.getAttributeNode('width').nodeValue		= widthStartDate;
	tdElementFinishDate.getAttributeNode('width').nodeValue		= widthFinishDate;
	tdElementIsFinished.getAttributeNode('width').nodeValue		= widthIsFinished;

// tr要素の作成
	var trElement = document.createElement("tr");

// タグの組み立て
// fontタグにテキストノードを追加
	tdFontNo.appendChild(tdTextNo);
	tdFontProjectCode.appendChild(tdTextProjectCode);
	tdFontProjectName.appendChild(tdTextProjectName);
	tdFontSectionName.appendChild(tdTextSectionName);
	tdFontManagerName.appendChild(tdTextManagerName);
	tdFontStartDate.appendChild(tdTextStartDate);
	tdFontFinishDate.appendChild(tdTextFinishDate);
	tdFontIsFinished.appendChild(tdTextIsFinished);

// tdタグにfontタグを追加
	tdElementNo.appendChild(tdFontNo);
	tdElementProjectCode.appendChild(tdFontProjectCode);
	tdElementProjectName.appendChild(tdFontProjectName);
	tdElementSectionName.appendChild(tdFontSectionName);
	tdElementManagerName.appendChild(tdFontManagerName);
	tdElementStartDate.appendChild(tdFontStartDate);
	tdElementFinishDate.appendChild(tdFontFinishDate);
	tdElementIsFinished.appendChild(tdFontIsFinished);
		
// trタグ内にtdタグ内容を追加
	trElement.appendChild(tdElementNo);				// No.
	trElement.appendChild(tdElementProjectCode);	// プロジェクトコード
	trElement.appendChild(tdElementProjectName);	// プロジェクト名
	trElement.appendChild(tdElementSectionName);	// 組織名
	trElement.appendChild(tdElementManagerName);	// マネージャ名
	trElement.appendChild(tdElementStartDate);		// 開始日
	trElement.appendChild(tdElementFinishDate);		// 終了日
	trElement.appendChild(tdElementIsFinished);		// ステータス

// tbodyタグ内にtrタグの内容を追加
	tableHead.appendChild(trElement);
}


// =================================================================================================
// 「Sample.config」ファイルの情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：「Sample.config」ファイルの情報を読み込み、サーバーマシン名とWebサイト名を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadSampleConfig() {
// オブジェクト作成
	var ConfigFile = new ActiveXObject("Microsoft.XMLDOM");

// configファイルの読み込み
	ConfigFile.load("./../Sample.config");

	if (ConfigFile.getElementsByTagName("SampleConfig").length == 0) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "Sample.configが正常に読み込めません。";
	} else {
	// サーバーマシン名とWebサイト名の取得
		ServerName		= ConfigFile.getElementsByTagName("ServerName")[0].text;	// サーバーマシン名（ホスト名）
		TTFXWebServer	= ConfigFile.getElementsByTagName("TTFXWebServer")[0].text;	// Webサイト名

		if (ServerName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "Sample.configのServerNameにホスト名が入力されいません。\n";
		}

		if (TTFXWebServer == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "Sample.configのTTFXWebServerにWebサイト名が入力されいません。";
		}
	}
}


// =================================================================================================
// ログイン情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：URLのクエリパラメータのログイン情報を読み込み、ログイン名とパスワードを取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadLoginAccountData() {
// URLのクエリパラメータの取得
	var loginNameAndPass = location.search;

	if (loginNameAndPass == "") {
		error_Flag	= 1;
		error_MSG	= error_MSG + "login.htmlよりツールを起動してください。";
	} else {
		loginNameAndPass	= loginNameAndPass.substring(1,loginNameAndPass.length);
		var arrayQP			= loginNameAndPass.split("&");

	// ログイン名とパスワードを取得
		loginName	= arrayQP[0].split("=")[1];
		loginPass	= arrayQP[1].split("=")[1];

		if (loginName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "ログイン名を入力してください。";
		}
	}
}


// =================================================================================================
// HTTPリクエストのレスポンス情報の確認する
// -------------------------------------------------------------------------------------------------
// 概要　　：HTTPリクエストのレスポンスに応じて、エラーメッセージを設定します。
// 入力値　：responseCode ･･･ レスポンスコード
// 戻り値　：無
// =================================================================================================
function CheckHttpRequestResponse(responseCode) {
	switch (responseCode) {
		case 200:
		//	error_MSG = error_MSG + "エラーはありません。";
			break;
		case 400:
			error_Flag	= 1;
			error_MSG	= error_MSG + "パラメータやリクエストに不備があります。";
			break;
		case 401:
			error_Flag	= 1;
			error_MSG	= error_MSG + "認証に失敗しました。\n";
			error_MSG	= error_MSG + "ログイン名またはパスワードに誤りがあります。\n";
			break;
		case 404:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したソース(URI)が存在しません。";
			break;
		case 405:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したHTTPメソッドが使用できません。";
			break;
		case 411:
			error_Flag	= 1;
			error_MSG	= error_MSG + "HTTP リクエストヘッダにContent-Lengthが指定されていません。";
			break;
		case 500:
			error_Flag	= 1;
			error_MSG	= error_MSG + "サーバーでエラーが発生しました。";
			break;
		default:
			error_Flag	= 1;
			error_MSG	= error_MSG + "エラーが発生しました。\n";
			error_MSG	= error_MSG + "Sample.configに不備がある可能性があります。";
			break;
	}
}


// =================================================================================================
// 画面上に表示された情報を削除する
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面（プロジェクト一覧）に表示された情報を削除します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function DeleteDisplayData() {
// 削除箇所の指定
	var resultTable	= document.getElementById("resultTable");

// thead内の情報を削除
	var tableHead	= resultTable.getElementsByTagName("thead")[0];
	var arrayTr		= tableHead.getElementsByTagName("tr");

	if (arrayTr.length != 0) {
	// trタグの削除
		tableHead.removeChild(arrayTr[0]);
	}

// tbody内の情報を削除
	var tableBody	= resultTable.getElementsByTagName("tbody")[0];
	var arrayTr		= tableBody.getElementsByTagName("tr");
	var arrTrLen	= arrayTr.length;

	for (var y = 0; y < arrTrLen; y++) {
	// trタグの削除
		tableBody.removeChild(arrayTr[0]);
	}
}


// =================================================================================================
// 取得した情報をCSVファイルに出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：取得した情報をCSVファイルに出力します。
// 入力値　：outputIdArray ･･･ プロジェクトIDの配列
// 戻り値　：無
// =================================================================================================
function OutputCSVFile(outputIdArray) {
// 上書き確認用フラグ
	var overwriteFlag = true;

// 出力先に指定されているパスとファイル名を取得
	var fileName = document.getElementById("output").value;

// 拡張子の確認
	var extension = fileName.slice(-4, fileName.length);

	if ((extension != ".csv") && (extension != ".CSV")) {
		fileName = fileName + ".csv";
	}

// ファイル出力
	try {
	// ファイルシステムオブジェクトの生成
		var FSO = new ActiveXObject("Scripting.FileSystemObject");

	// ファイルの有無の確認
		if (FSO.FileExists(fileName)) {
			overwriteFlag = confirm("すでにCSVファイルが存在します。\n上書きしてもよろしいですか。");
		}

	// ファイル出力実施
		if (overwriteFlag) {
			var file = FSO.OpenTextFile(fileName, 2, true, 0); // 書き込みモード、新規ファイル作成
			var STR;

		// ヘッダー出力
			STR = "No.,プロジェクトコード,プロジェクト名,組織名,マネージャ名,開始日,終了日,ステータス\n";

		// メインの情報の構成
			for (var i = 0; i < outputIdArray.length; i++) {
				var NUM = i + 1;
				STR = STR + NUM
						+ "," + arrayProjectCode["ProjectId_" + outputIdArray[i]]
						+ "," + arrayProjectName["ProjectId_" + outputIdArray[i]]
						+ "," + arraySectionName["ProjectId_" + outputIdArray[i]]
						+ "," + arrayManagerName["ProjectId_" + outputIdArray[i]]
						+ "," + arrayStartDate["ProjectId_" + outputIdArray[i]]
						+ "," + arrayFinishDate["ProjectId_" + outputIdArray[i]]
						+ "," + arrayIsFinished["ProjectId_" + outputIdArray[i]] + "\n";
			}

		// ファイルに書き込み
			file.Write(STR);
			file.Close();
			confirm("以下にCSVファイルを出力しました。\n" + fileName);
		} else {
			confirm("CSVファイルの出力はキャンセルされました。");
		}
	}
	catch(e) {
		error_Flag	= 1
		error_MSG	= error_MSG + "ファイル出力エラー\n";
		error_MSG	= error_MSG + e.description;
	}
}


// =================================================================================================
// プログラム内の変数を初期化する
// -------------------------------------------------------------------------------------------------
// 概要　　：プログラム内の変数を初期化します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function OffsetValue() {
// 初期化
	filterProjectName	= "";
	filterManagerName	= "";
	filterSectionName	= "";
	selectFinished		= "";
	selectQuickFilter	= "";
	sortTarget1			= "sortProjectCode";
	sortTarget2			= "";
	sortType1			= "";
	sortType2			= "";
	arrayProjectId		= new Array();
	arrayProjectCode	= new Array();
	arrayProjectName	= new Array();
	arraySectionName	= new Array();
	arrayManagerName	= new Array();
	arrayStartDate		= new Array();
	arrayFinishDate		= new Array();
	arrayIsFinished		= new Array();
	error_MSG			= "";
	error_Flag			= 0;
}
