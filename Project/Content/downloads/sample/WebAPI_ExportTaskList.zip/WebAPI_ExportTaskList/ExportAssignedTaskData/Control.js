
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □             「アカウント別割り当て済みタスク出力ツール」サブプログラム（制御系）             □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルはアカウントの追加や削除など、［アカウント別割り当て済みタスク出力ツール］の      □
// □  インターフェイス操作の制御系の処理を実施します。                                            □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  ClickAddAccountButton()       ・・・ アカウント選択の［追加（→）］ボタンクリック時の制御   □
// □  ClickDelAccountButton()       ・・・ アカウント選択の［削除（←）］ボタンクリック時の制御   □
// □  ClickAllAccountSelectButton() ・・・ ［全選択］ボタンクリック時の制御                       □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// アカウント選択の［追加（→）］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：［アカウント一覧］で選択されたアカウントを［指定アカウント」に追加します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickAddAccountButton() {
// 変更箇所の指定
	var selectAL	= document.getElementsByName("accountList")[0];
	var optionAL	= selectAL.getElementsByTagName("option");

	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

// アカウント一覧で選択されているアカウントの検索
	for (var i = 0; i < optionAL.length; i++) {
		if (optionAL[i].selected) {

		// 追加フラグ（0:追加しない,1:追加する）
			var addFlag = 1;

		// 指定アカウントの重複回避処理
			for (var j = 0; j < optionTA.length; j++) {
				if (document.setting.accountList.options[i].value == document.setting.targetAccount.options[j].value) {
					addFlag = 0;
				}
			}

		// 追加フラグが1のとき指定用のリストに追加
			if (addFlag == 1) {
			// アカウント名を格納したテキストノード作成
				var optionText	= document.createTextNode(document.setting.accountList.options[i].text);

			// optionタグの作成
				var newOption	= document.createElement("option");

			// optionタグのvalue属性にアカウントIDを格納
				newOption.getAttributeNode('value').nodeValue = document.setting.accountList.options[i].value;

			// タグの組み立て
				newOption.appendChild(optionText);
				selectTA.appendChild(newOption);
			}

		// 非選択状態にする
			optionAL[i].selected = "";
		}
	}

}


// =================================================================================================
// アカウント選択の［削除（←）］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：［指定アカウント］で選択されたアカウントを削除します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ClickDelAccountButton() {
// 対象の指定
	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

	var tempLength = optionTA.length;

// 選択箇所の検索と削除
	for (var i = 0; i < tempLength; i++) {
		if (optionTA[i].selected) {
			selectTA.removeChild(optionTA[i]);
			tempLength--;
			i--;
		}
	}
}


// =================================================================================================
// ［全選択］ボタンクリック時の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：セレクトボックス内の要素すべてを選択状態にします。
// 入力値　：target　…　対象のセレクトボックス（0：アカウント一覧,1：指定アカウント）
// 戻り値　：無
// =================================================================================================
function ClickAllAccountSelectButton(target) {
// 変更箇所の指定用の変数
	var selectBox;

// 対象のセレクトボックスの選択
	if (target == 0) {
		selectBox = document.getElementsByName("accountList")[0];
	} else {
		selectBox = document.getElementsByName("targetAccount")[0];
	}

// option要素の配列の取得
	var arrayOption = selectBox.getElementsByTagName("option");

// 全選択
	for (var i = arrayOption.length; 0 < i; i--) {
		arrayOption[i - 1].selected = "true";
	}
}
