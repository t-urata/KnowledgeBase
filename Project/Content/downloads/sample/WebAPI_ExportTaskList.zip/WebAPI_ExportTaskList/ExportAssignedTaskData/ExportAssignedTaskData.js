
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □          「アカウント別割り当て済みタスク出力ツール」メインプログラム（情報取得系）          □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「タスクツリー」や「条件設定に利用するアカウントの一覧」など                    □
// □  ［アカウント別割り当て済みタスク出力ツール］で行う情報取得系の処理を実施します。            □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  SetDefaultSettingView()          ・・・ 条件設定画面の初期値を設定する                      □
// □  GetSectionDataList()             ・・・ 組織情報の一覧を取得する                            □
// □  GetAccountDataList()             ・・・ アカウント情報の一覧を取得する                      □
// □  ChangeSectionFilter()            ・・・ 組織フィルタ利用時アカウント一覧の情報を絞り込む    □
// □  ExportAssignedTaskData() 　　　  ・・・ タイムシートの情報を取得し、タスク情報を出力する    □
// □  GetAssignedProjectList()         ・・・ タスクツリーのプロジェクト一覧を情報を取得する      □
// □  GetAssignedTaskList()            ・・・ タスクツリーを情報を取得する                        □
// □  GetChildrenWBSNode()             ・・・ 子ノードの情報取得する                              □
// □  AddArrayAccountTask()            ・・・ ノードの情報取得する                                □
// □  OutputFile()                     ・・・ 取得した情報をファイルに出力する                    □
// □  ReadSampleConfig()               ・・・ 「SampleConfig.xml」ファイルの情報を読み込む        □
// □  ReadLoginAccountData()           ・・・ ログイン情報を読み込む                              □
// □  ChangeSettingView()              ・・・ 設定画面表示切替の制御                              □
// □  CheckHttpRequestResponse()       ・・・ HTTPリクエストのレスポンス情報の確認する            □
// □  CreateMinuteToHour()             ・・・ 分単位から時間単位の時刻を作成する                  □
// □  CreateOutlineSequence()          ・・・ アウトラインシーケンスを作成する                    □
// □  GetCrossSortData()               ・・・ ソート（クロスソート）を実施する                    □
// □  OffsetValue()                    ・・・ プログラム内の変数を初期化する                      □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// 内部共通変数の宣言
// -------------------------------------------------------------------------------------------------
// 概要　　：「予実情報出力ツール」で利用する共通の変数を宣言します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
// ログイン情報
	var loginName;		// ログイン名
	var loginPass;		// パスワード

// 接続先情報
	var ServerName;		// サーバーマシン名（ホスト名）
	var TTFXWebServer;	// Web サイト名

// アカウント一覧用の配列
	var arrayAccountId;				// アカウントIDの配列
	var arrayAccountName;			// アカウント名の配列
	var arrayAccountCode;			// アカウントコードの配列
	var arrayAccountSectionId;		// アカウントの組織IDの配列

// 集計用配列の宣言（アカウント×タスク）
	var idCount;							// idカウンタ
	var arrayAccountTaskId;					// アカウント×タスクのID
	var	arrayAccountTaskNodeId;				// ノードID
	var	arrayAccountTaskAccountId;			// アカウントID
	var arrayAccountTaskAccountCode;			// アカウントコード
	var arrayAccountTaskAccountName;			// アカウント名
	var arrayAccountTaskProjectCode;		// プロジェクトコード
	var arrayAccountTaskProjectName;		// プロジェクト名
	var arrayAccountTaskOutlineNumber;		// アウトライン番号
	var arrayAccountTaskOutlineSequence;	// アウトラインシーケンス
	var arrayAccountTaskNodePath;			// ノードパス
	var arrayAccountTaskTaskName;			// タスク名
	var arrayAccountTaskStartDate;			// 開始日
	var arrayAccountTaskFinishDate;			// 終了日
	var arrayAccountTaskPlannedTime;		// 計画工数
	var arrayAccountTaskActualTime;			// 実績工数
	var arrayAccountTaskAssignmentProgress;	// 進捗率（個人）

// エラー処理用変数
	var error_MSG;	// エラーメッセージ
	var error_Flag;	// エラーフラグ（0:エラー無し、1：エラー有り）


// =================================================================================================
// 条件設定画面の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、条件設定画面の初期値を設定します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultSettingView() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 接続先情報の確認
	if (error_Flag == 0) {
		ReadSampleConfig();
	}

// ログイン情報の確認
	if (error_Flag == 0) {
		ReadLoginAccountData();
	}

// 組織一覧の取得と表示
	if (error_Flag == 0) {
		GetSectionDataList();
	}

// アカウント一覧の取得と表示
	if (error_Flag == 0) {
		GetAccountDataList();
	}

// 設定画面の設定
	if (error_Flag == 0) {
	// 設定画面の表示
		ChangeSettingView();
	}

// エラーの表示
	if (error_Flag == 1) {
	// ログイン画面に戻る
		window.location.href = "./login.html";
		alert(error_MSG);
	}
}


// =================================================================================================
// 組織情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：組織一覧を取得し、組織フィルタを表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetSectionDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/sections";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

		var arraySection = xml.getElementsByTagName("section");

	// 組織フィルタの一覧の表示
		var selectSF = document.getElementsByName("sectionFilter")[0];

		for (var i = 0; i < arraySection.length; i++) {
			var sectionId	= arraySection[i].getElementsByTagName("id")[0].text;
			var sectionName	= arraySection[i].getElementsByTagName("name")[0].text;

		// 組織名のテキストノード作成
			var optionText = document.createTextNode(sectionName);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = sectionId;

		// 組立
			newOption.appendChild(optionText);
			selectSF.appendChild(newOption);
		}
	}
}


// =================================================================================================
// アカウント情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetAccountDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/accounts";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

		var arrayAccount = xml.getElementsByTagName("account");

	// 配列の初期化
		arrayAccountId			= new Array();
		arrayAccountName		= new Array();
		arrayAccountCode		= new Array();
		arrayAccountSectionId	= new Array();

	// アカウント一覧を配列に格納
		for (var i = 0; i < arrayAccount.length; i++) {
			arrayAccountId[i]											= arrayAccount[i].getElementsByTagName("id")[0].text;
			arrayAccountName		["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("name")[0].text;
			arrayAccountCode		["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("code")[0].text;
			arrayAccountSectionId	["AccountId_" + arrayAccountId[i]]	= arrayAccount[i].getElementsByTagName("sectionId")[0].text;
		}

	// アカウント一覧の作成
		var selectAL = document.getElementsByName("accountList")[0];

		for (var i = 0; i < arrayAccount.length; i++) {
		// アカウント名のテキストノード作成
			var optionText = document.createTextNode(arrayAccountName["AccountId_" + arrayAccountId[i]]);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = arrayAccountId[i];

		// 組立
			newOption.appendChild(optionText);
			selectAL.appendChild(newOption);
		}
	}
}


// =================================================================================================
// 組織フィルタ利用時アカウント一覧の情報を絞り込む
// -------------------------------------------------------------------------------------------------
// 概要　　：組織フィルタで組織選択時に、アカウント一覧の情報をすべて削除し、
// 　　　　　選択組織に所属するアカウントに絞り込んで再表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSectionFilter() {
// 選択中の組織IDの取得
	var selectSectionId = document.setting.sectionFilter.value;

// アカウント一覧の削除
	var selectAL = document.getElementsByName("accountList")[0];

	while (selectAL.firstChild) {
	  selectAL.removeChild(selectAL.firstChild);
	}

// アカウント一覧の再作成
	for (var i = 0; i < arrayAccountId.length; i++) {
	// 選択中の組織で絞り込み
		if ((selectSectionId == arrayAccountSectionId["AccountId_" + arrayAccountId[i]]) || (selectSectionId == 0)) {
		// アカウント名のテキストノード作成
			var optionText = document.createTextNode(arrayAccountName["AccountId_" + arrayAccountId[i]]);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = arrayAccountId[i];

		// 組立
			newOption.appendChild(optionText);
			selectAL.appendChild(newOption);
		}
	}
}


// =================================================================================================
// 指定アカウントのタイムシートの情報を取得し、割り当て済みタスクの情報を出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントのタスクツリーの情報を取得し、タスクの情報を出力します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ExportAssignedTaskData() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 変数の初期化
	idCount	= -1;
	arrayAccountTaskId					= new Array();
	arrayAccountTaskNodeId				= new Array();
	arrayAccountTaskAccountId			= new Array();
	arrayAccountTaskAccountCode			= new Array();
	arrayAccountTaskAccountName			= new Array();
	arrayAccountTaskProjectCode			= new Array();
	arrayAccountTaskProjectName			= new Array();
	arrayAccountTaskOutlineNumber		= new Array();
	arrayAccountTaskOutlineSequence		= new Array();
	arrayAccountTaskNodePath			= new Array();
	arrayAccountTaskTaskName			= new Array();
	arrayAccountTaskStartDate			= new Array();
	arrayAccountTaskFinishDate			= new Array();
	arrayAccountTaskPlannedTime			= new Array();
	arrayAccountTaskActualTime			= new Array();
	arrayAccountTaskAssignmentProgress	= new Array();

// 指定アカウントのタスクツリーを取得
	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

	if (optionTA.length != 0) {
		for (var i = 0; i < optionTA.length; i++) {
			var tempId = document.setting.targetAccount.options[i].value;

		// 該当アカウントのタスクツリーの取得
			GetAssignedProjectList(tempId);
		}
	} else {
		error_Flag	= 1;
		error_MSG	= error_MSG + "アカウントが指定されていません。";
	}

// 情報の出力
	if (error_Flag == 0) {
	// 情報の有無の確認
		if (arrayAccountTaskId.length != 0) {
			// ソート（アカウントコード昇順、プロジェクトコード降順、アウトラインシーケンスの昇順）
			var resultSort = GetCrossSortData(arrayAccountTaskAccountCode, arrayAccountTaskProjectCode, arrayAccountTaskOutlineSequence);

			if (document.setting.outputSwitch[0].checked) {
			// TSVファイル出力
				OutputFile(resultSort, 0);
			} else if (document.setting.outputSwitch[1].checked) {
			// CSVファイル出力
				OutputFile(resultSort, 1);
			}

		} else {
			error_Flag	= 1;
			error_MSG	= error_MSG + "取得可能な情報がありません。";
		}
	}

// エラーの表示
	if (error_Flag == 1) {
		alert(error_MSG);
	}

// 変数の初期化
	OffsetValue();
}


// =================================================================================================
// アカウントのタスクツリーのプロジェクト一覧を情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントのタスクツリーのプロジェクト一覧を取得し、
// 　　　　　プロジェクトごとにタスクツリーを取得します。
// 入力値　：accountId ･･･ 取得対象のアカウントID
// 戻り値　：無
// =================================================================================================
function GetAssignedProjectList(accountId) {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/assignedProjects";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayAssignedProject = xml.getElementsByTagName("assignedProject");

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayAssignedProject.length; i++) {
		var tempProjectId = arrayAssignedProject[i].getElementsByTagName("id")[0].text;
		GetAssignedTaskList(accountId, tempProjectId)
	}
}


// =================================================================================================
// アカウントのタスクツリーを情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントの指定プロジェクトのタスクツリーの情報を取得します。
// 入力値　：accountId ･･･ 取得対象のアカウントID
// 　　　　　projectId ･･･ 取得対象のプロジェクトID
// 戻り値　：無
// =================================================================================================
function GetAssignedTaskList(accountId, projectId) {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// XMLの読み込みを同期に設定
	xml.async = false;

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/assignedProjects/" + projectId + "/assignedTasks";
	var queryParameter	= "?limit=0&convertType=tree&includeTaskPackage=TRUE";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayAssignedTask = xml.getElementsByTagName("assignedTasks")[0].childNodes;

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayAssignedTask.length; i++) {
	// ノード名、ノードコードの取得とノードパスの作成
		var tempProjectName = arrayAssignedTask[i].getElementsByTagName("projectName")[0].text;
		var tempProjectCode = arrayAssignedTask[i].getElementsByTagName("projectCode")[0].text;
		var tempNodePath = "";

		if (tempProjectCode == "") {
			tempNodePath = tempProjectName + "/" + arrayAssignedTask[i].getElementsByTagName("name")[0].text;
		}
		else {
			tempNodePath =  "[" + tempProjectCode + "]" + tempProjectName + "/" + arrayAssignedTask[i].getElementsByTagName("name")[0].text;
		}

	// ノードの種類の判定
		switch (arrayAssignedTask[i].getElementsByTagName("kind")[0].text) {
			case "task":
			// タスクの場合、各項目用配列に格納
				idCount++;
				arrayAccountTaskId[idCount] = "AccountId_" + accountId + "_TaskId_" + arrayAssignedTask[i].getElementsByTagName("nodeId")[0].text;
				arrayAccountTaskNodeId					[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("nodeId")[0].text;
				arrayAccountTaskAccountId				[arrayAccountTaskId[idCount]] = accountId;
				arrayAccountTaskAccountCode				[arrayAccountTaskId[idCount]] = arrayAccountCode["AccountId_" + accountId];
				arrayAccountTaskAccountName				[arrayAccountTaskId[idCount]] = arrayAccountName["AccountId_" + accountId];
				arrayAccountTaskProjectCode				[arrayAccountTaskId[idCount]] = tempProjectCode;
				arrayAccountTaskProjectName				[arrayAccountTaskId[idCount]] = tempProjectName;
				arrayAccountTaskOutlineNumber			[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("outlineNumber")[0].text;
				arrayAccountTaskOutlineSequence			[arrayAccountTaskId[idCount]] = CreateOutlineSequence(arrayAssignedTask[i].getElementsByTagName("outlineNumber")[0].text);
				arrayAccountTaskNodePath				[arrayAccountTaskId[idCount]] = tempNodePath;
				arrayAccountTaskTaskName				[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("name")[0].text;

				// 計画期間がない場合は、開始日・終了日を空欄に設定
				if (arrayAssignedTask[i].getElementsByTagName("plannedStartDate")[0].text == "1753/01/01") {
					arrayAccountTaskStartDate			[arrayAccountTaskId[idCount]] = "";
					arrayAccountTaskFinishDate			[arrayAccountTaskId[idCount]] = "";
				} else {
					arrayAccountTaskStartDate			[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("plannedStartDate")[0].text;
					arrayAccountTaskFinishDate			[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("plannedFinishDate")[0].text;
				}

				arrayAccountTaskPlannedTime				[arrayAccountTaskId[idCount]] = CreateMinuteToHour(arrayAssignedTask[i].getElementsByTagName("plannedTime")[0].text);
				arrayAccountTaskActualTime				[arrayAccountTaskId[idCount]] = CreateMinuteToHour(arrayAssignedTask[i].getElementsByTagName("actualTime")[0].text);

				// 進捗率を管理しない場合は「N/A」を設定
				if (arrayAssignedTask[i].getElementsByTagName("progressExpression")[0].text == "notUsed") {
					arrayAccountTaskAssignmentProgress	[arrayAccountTaskId[idCount]] = "N/A";
				} else {
					arrayAccountTaskAssignmentProgress	[arrayAccountTaskId[idCount]] = arrayAssignedTask[i].getElementsByTagName("assignmentProgress")[0].text;
				}
				break;
			case "taskPackage":
			// タスクパッケージの場合、子ノードの情報取得
				GetChildrenWBSNode(arrayAssignedTask[i], 2, tempNodePath, accountId);
				break;
		}
	}
}


// =================================================================================================
// 子ノードの情報取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定タスクパッケージ内の子ノードの情報を取得します。
// 入力値　：assignedTask ･･･ 対象のassignedTaskオブジェクト（タスクパッケージのみ）
// 　　　　　levelCount   ･･･ 対象ノードのアウトラインレベル
// 　　　　　nodePath     ･･･ 対象ノードのノードパス
// 　　　　　accountId    ･･･ 取得対象のアカウントID
// 戻り値　：無
// =================================================================================================
function GetChildrenWBSNode(assignedTask, levelCount, nodePath, accountId) {
	var childAssignedTasks = assignedTask.getElementsByTagName("children")[0].childNodes;

// 子ノードの情報を配列への格納
	for (var c = 0; c < childAssignedTasks.length; c++) {
		var childAssignedTask = childAssignedTasks[c];
		var tempNodePath = AddArrayAccountTask(childAssignedTask, nodePath, accountId);

	// ノードの種類とアウトラインレベルの判定
		if ((childAssignedTask.getElementsByTagName("kind")[0].text == "taskPackage") && (levelCount < 16)) {
		// 次階層の処理へ
			levelCount++;
			GetChildrenWBSNode(childAssignedTask, levelCount, tempNodePath, accountId);
			levelCount--;
		}
	}
}


// =================================================================================================
// ノードの情報取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定ノードの情報を取得します。
// 入力値　：assignedTask ･･･ 対象のassignedTaskオブジェクト
// 　　　　　nodePath     ･･･ 親ノードのノードパス
// 　　　　　accountId    ･･･ 取得対象のアカウントID
// 戻り値　：thisNodePath ･･･ 対象ノードのノードパス
// =================================================================================================
function AddArrayAccountTask(assignedTask, nodePath, accountId) {
// ノードパスの作成
	var thisNodePath = nodePath + "/" + assignedTask.getElementsByTagName("name")[0].text;

// ノードの種類の判定
	if (assignedTask.getElementsByTagName("kind")[0].text == "task") {
	// タスクの場合各項目用配列に格納
		idCount++;
		arrayAccountTaskId[idCount] = "AccountId_" + accountId + "_TaskId_" + assignedTask.getElementsByTagName("nodeId")[0].text;
		arrayAccountTaskNodeId					[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("nodeId")[0].text;
		arrayAccountTaskAccountId				[arrayAccountTaskId[idCount]] = accountId;
		arrayAccountTaskAccountCode				[arrayAccountTaskId[idCount]] = arrayAccountCode["AccountId_" + accountId];
		arrayAccountTaskAccountName				[arrayAccountTaskId[idCount]] = arrayAccountName["AccountId_" + accountId];
		arrayAccountTaskProjectCode				[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("projectCode")[0].text;
		arrayAccountTaskProjectName				[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("projectName")[0].text;
		arrayAccountTaskOutlineNumber			[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("outlineNumber")[0].text;
		arrayAccountTaskOutlineSequence			[arrayAccountTaskId[idCount]] = CreateOutlineSequence(assignedTask.getElementsByTagName("outlineNumber")[0].text);
		arrayAccountTaskNodePath				[arrayAccountTaskId[idCount]] = thisNodePath;
		arrayAccountTaskTaskName				[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("name")[0].text;

		// 計画期間がない場合は、開始日・終了日を空欄に設定
		if (assignedTask.getElementsByTagName("plannedStartDate")[0].text == "1753/01/01") {
			arrayAccountTaskStartDate			[arrayAccountTaskId[idCount]] = "";
			arrayAccountTaskFinishDate			[arrayAccountTaskId[idCount]] = "";
		} else {
			arrayAccountTaskStartDate			[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("plannedStartDate")[0].text;
			arrayAccountTaskFinishDate			[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("plannedFinishDate")[0].text;
		}

		arrayAccountTaskPlannedTime				[arrayAccountTaskId[idCount]] = CreateMinuteToHour(assignedTask.getElementsByTagName("plannedTime")[0].text);
		arrayAccountTaskActualTime				[arrayAccountTaskId[idCount]] = CreateMinuteToHour(assignedTask.getElementsByTagName("actualTime")[0].text);

		// 進捗率を管理しない場合は「N/A」を設定
		if (assignedTask.getElementsByTagName("progressExpression")[0].text == "notUsed") {
			arrayAccountTaskAssignmentProgress	[arrayAccountTaskId[idCount]] = "N/A";
		} else {
			arrayAccountTaskAssignmentProgress	[arrayAccountTaskId[idCount]] = assignedTask.getElementsByTagName("assignmentProgress")[0].text;
		}
	}

	return thisNodePath;
}


// =================================================================================================
// 取得した情報をファイルに出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：情報をTSV形式またはCSV形式でファイルに出力します。
// 入力値　：outputIdArray ･･･ IDの配列
// 　　　　　type          ･･･ 出力形式（0:TSV形式,1:CSV形式）
// 戻り値　：無
// =================================================================================================
function OutputFile(outputIdArray, type) {
// 上書き確認用フラグ
	var overwriteFlag = true;

// 出力先に指定されているパスとファイル名を取得
	var filename = document.getElementById("output").value;

// 拡張子の確認
	var extension = filename.slice(-4, filename.length);
	extension = extension.toLowerCase()

	switch (type) {
		case 0:
			if (extension != ".tsv") {
				filename = filename + ".tsv";
			}
			break;
		case 1:
			if (extension != ".csv") {
				filename = filename + ".csv";
			}
			break;
	}

// ファイル出力
	try {
	// ファイルシステムオブジェクトの生成
		var FSO =new ActiveXObject("Scripting.FileSystemObject");

	// ファイルの有無の確認
		if (FSO.FileExists(filename)) {
			overwriteFlag = confirm("以下のファイルがすでに存在します。\n上書きしてもよろしいですか。\n\n" + filename);
		}

	// ファイル出力実施
		if (overwriteFlag) {
			var file = FSO.OpenTextFile(filename, 2, true, 0); // 書き込みモード、新規ファイル作成

			switch (type) {
				case 0:	// TSV出力
				// ヘッダー出力
					var STR = "アカウントコード\tアカウント名\tプロジェクトコード\tプロジェクト名\tアウトライン番号\tアウトラインシーケンス\tタスク名\t開始日\t終了日\t計画工数\t実績工数\t進捗率（個人）\tノードパス\r\n";

				// 情報の出力
					for (var i = 0; i < outputIdArray.length; i++) {
						STR = STR + arrayAccountTaskAccountCode			[outputIdArray[i]] + "\t" +
									arrayAccountTaskAccountName			[outputIdArray[i]] + "\t" +
									arrayAccountTaskProjectCode			[outputIdArray[i]] + "\t" +
									arrayAccountTaskProjectName			[outputIdArray[i]] + "\t" +
									arrayAccountTaskOutlineNumber		[outputIdArray[i]] + "\t" +
									arrayAccountTaskOutlineSequence		[outputIdArray[i]] + "\t" +
									arrayAccountTaskTaskName			[outputIdArray[i]] + "\t" +
									arrayAccountTaskStartDate			[outputIdArray[i]] + "\t" +
									arrayAccountTaskFinishDate			[outputIdArray[i]] + "\t" +
									arrayAccountTaskPlannedTime			[outputIdArray[i]] + "\t" +
									arrayAccountTaskActualTime			[outputIdArray[i]] + "\t" +
									arrayAccountTaskAssignmentProgress	[outputIdArray[i]] + "\t" +
									arrayAccountTaskNodePath			[outputIdArray[i]] + "\r\n";

					}
					break;
				case 1:	// CSV出力
				// ヘッダー出力
					var STR = "アカウントコード,アカウント名,プロジェクトコード,プロジェクト名,アウトライン番号,アウトラインシーケンス,タスク名,開始日,終了日,計画工数,実績工数,進捗率（個人）,ノードパス\r\n";

				// 情報の出力
					for (var i = 0; i < outputIdArray.length; i++) {
						STR = STR + arrayAccountTaskAccountCode			[outputIdArray[i]] + "," +
									arrayAccountTaskAccountName			[outputIdArray[i]] + "," +
									arrayAccountTaskProjectCode			[outputIdArray[i]] + "," +
									arrayAccountTaskProjectName			[outputIdArray[i]] + "," +
									arrayAccountTaskOutlineNumber		[outputIdArray[i]] + "," +
									arrayAccountTaskOutlineSequence		[outputIdArray[i]] + "," +
									arrayAccountTaskTaskName			[outputIdArray[i]] + "," +
									arrayAccountTaskStartDate			[outputIdArray[i]] + "," +
									arrayAccountTaskFinishDate			[outputIdArray[i]] + "," +
									arrayAccountTaskPlannedTime			[outputIdArray[i]] + "," +
									arrayAccountTaskActualTime			[outputIdArray[i]] + "," +
									arrayAccountTaskAssignmentProgress	[outputIdArray[i]] + "," +
									arrayAccountTaskNodePath			[outputIdArray[i]] + "\r\n";
					}
					break;
			}

		// ファイルに書き込み
			file.Write(STR);
			file.Close();
			STR = "";
			confirm("以下のとおりファイルを出力しました。\n\n" + filename);
		} else {
			confirm("ファイルの出力はキャンセルされました。");
		}
	} catch (e) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "ファイル出力エラー\n";
		error_MSG	= error_MSG + e.description;
	}
}


// =================================================================================================
// 「SampleConfig.xml」ファイルの情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：「SampleConfig.xml」ファイルの情報を読み込み、サーバーマシン名とWebサイト名を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadSampleConfig() {
// オブジェクト作成
	var ConfigFile = new ActiveXObject("Microsoft.XMLDOM");

// XMLの読み込みを同期に設定
	ConfigFile.async = false;

// configファイルの読み込み
	ConfigFile.load("./../SampleConfig.xml");

	if (ConfigFile.getElementsByTagName("SampleConfig").length == 0) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "SampleConfig.xmlが正常に読み込めません。";
	} else {
	// サーバーマシン名とWeb サイト名の取得
		ServerName		= ConfigFile.getElementsByTagName("ServerName")[0].text;	// サーバーマシン名（ホスト名）
		TTFXWebServer	= ConfigFile.getElementsByTagName("TTFXWebServer")[0].text;	// Webサイト名

		if (ServerName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "SampleConfig.xmlのServerNameにホスト名が入力されていません。\n";
		}

		if (TTFXWebServer == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "SampleConfig.xmlのTTFXWebServerにWebサイト名が入力されていません。";
		}
	}
}


// =================================================================================================
// ログイン情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：URLのクエリパラメータのログイン情報を読み込み、ログイン名とパスワードを取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadLoginAccountData() {
// URLのクエリパラメータの取得
	var loginNameAndPass = location.search;

	if (loginNameAndPass == "") {
		error_Flag	= 1;
		error_MSG	= error_MSG + "login.htmlよりツールを起動してください。";
	} else {
		loginNameAndPass	= loginNameAndPass.substring(1,loginNameAndPass.length);
		var arrayQP			= loginNameAndPass.split("&");

	// ログイン名とパスワードを取得
		loginName	= arrayQP[0].split("=")[1];
		loginPass	= arrayQP[1].split("=")[1];

		if (loginName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "ログイン名を入力してください。";
		}
	}
}


// =================================================================================================
// 設定画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面を非表示にし、設定画面を切り替えます。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSettingView() {
	document.getElementById("settingView").style.display	= "block";
}


// =================================================================================================
// HTTPリクエストのレスポンス情報の確認する
// -------------------------------------------------------------------------------------------------
// 概要　　：HTTPリクエストのレスポンスに応じて、エラーメッセージを設定します。
// 入力値　：responseCode ･･･ レスポンスコード
// 戻り値　：無
// =================================================================================================
function CheckHttpRequestResponse(responseCode) {
	switch (responseCode) {
		case 200:
			break;
		case 400:
			error_Flag	= 1;
			error_MSG	= error_MSG + "パラメータやリクエストに不備があります。";
			break;
		case 401:
			error_Flag	= 1;
			error_MSG	= error_MSG + "認証に失敗しました。\n";
			error_MSG	= error_MSG + "ログイン名またはパスワードに誤りがあります。\n";
			break;
		case 404:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したソース(URI)が存在しません。";
			break;
		case 405:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したHTTPメソッドが使用できません。";
			break;
		case 411:
			error_Flag	= 1;
			error_MSG	= error_MSG + "HTTP リクエストヘッダにContent-Lengthが指定されていません。";
			break;
		case 500:
			error_Flag	= 1;
			error_MSG	= error_MSG + "サーバーでエラーが発生しました。";
			break;
		default:
			error_Flag	= 1;
			error_MSG	= error_MSG + "エラーが発生しました。\n";
			error_MSG	= error_MSG + "SampleConfig.xmlに不備がある可能性があります。";
			break;
	}
}


// =================================================================================================
// 分単位から時間単位に変換した時刻を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：分単位から時間単位に変換し、小数第2位まで表示した文字列を作成します。
// 入力値　：minute ･･･ 分
// 戻り値　：小数第2位まで表示した時間の文字列
// =================================================================================================
function CreateMinuteToHour(minute) {
// 分単位から時間単位に変換
	var tempTime = minute / 60;

// 小数第2位まで文字列に変換
	return(tempTime.toFixed(2));
}


// =================================================================================================
// アウトラインシーケンスを作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：アウトライン番号からアウトラインシーケンスを作成します。
// 入力値　：outlineNumber ･･･ アウトライン番号
// 戻り値　：アウトラインシーケンス
// =================================================================================================
function CreateOutlineSequence(outlineNumber) {
	var outlineSequence = "";
	var arrayOutlineNumber = outlineNumber.split(".");

	for (i in arrayOutlineNumber) {
		if (arrayOutlineNumber[i] < 10) {
			outlineSequence = outlineSequence + "00" + arrayOutlineNumber[i];
		} else if (arrayOutlineNumber[i] < 100) {
			outlineSequence = outlineSequence + "0" + arrayOutlineNumber[i];
		} else {
			outlineSequence = outlineSequence + arrayOutlineNumber[i];
		}
	}

	return outlineSequence;
}


// =================================================================================================
// ソート（クロスソート）を実施する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定した配列をソートします。
// 入力値　：input_Array1 ･･･ 1番目のキー
//           input_Array2 ･･･ 2番目のキー
//           input_Array3 ･･･ 3番目のキー
// 戻り値　：ソート後のIDの配列
// =================================================================================================
function GetCrossSortData(inputArray1, inputArray2, inputArray3) {
// 第1キーのソート
	// 第1キーソート用の1次元配列作成
	var sortArray1 = new Array()
	var count1 = 0;
	for (i in inputArray1) {
		sortArray1[count1] = inputArray1[i].toUpperCase() + " |id_" + i;
		count1++;
	}

	// 第1キーのソート（昇順）
	sortArray1.sort();

	// ソートされた第1キーのID取り出し
	var sortArray1_Id = new Array();
	for (var i = 0; i < sortArray1.length; i++) {
		sortArray1_Id[i] = sortArray1[i].split(" |id_")[1];
	}

// 第2キーのソート
	// 第2キーソート用の2次元配列作成
	var sortArray2 = new Array();
	var count2 = 0;
	var tempElement1 = "";
	count1 = 0;

	for (var i = 0; i < sortArray1_Id.length; i++) {
		if (i == 0) {
		// 初回実行時
			sortArray2[count1] = new Array();
			sortArray2[count1][count2] = inputArray2[sortArray1_Id[i]].toUpperCase() + " |id_" + sortArray1_Id[i];
			tempElement1 = inputArray1[sortArray1_Id[i]];
		} else if (tempElement1 == inputArray1[sortArray1_Id[i]]) {
		// 1つ前の第1キーの要素と同じ場合、2次元目を加算し、第2キーの要素を格納
			count2++;
			sortArray2[count1][count2] = inputArray2[sortArray1_Id[i]].toUpperCase() + " |id_" + sortArray1_Id[i];
		} else {
		// 1つ前の第1キーの要素と異なる場合、1次元目を加算し、第2キーの要素を格納
			count1++;
			count2 = 0;
			sortArray2[count1] = new Array();
			sortArray2[count1][count2] = inputArray2[sortArray1_Id[i]].toUpperCase() + " |id_" + sortArray1_Id[i];
			tempElement1 = inputArray1[sortArray1_Id[i]];
		}
	}

	// 第1キーごとに第2キーをソート（降順）
	for (var i = 0; i < sortArray2.length; i++) {
		sortArray2[i].sort();
		sortArray2[i].reverse();
	}

	// ソートされた第2キーのID取り出し
	var sortArray2_Id = new Array();
	var count = 0;
	for (var i = 0; i < sortArray2.length; i++) {
		for (var j = 0; j < sortArray2[i].length; j++) {
			sortArray2_Id[count] = sortArray2[i][j].split(" |id_")[1];
			count++;
		}
	}

// 第3キーのソート
	// 第3キーソート用の3次元配列作成
	var sortArray3 = new Array();
	var count3 = 0;
	var tempElement2 = "";
	count1 = 0;
	count2 = 0;
	tempElement1 = "";

	for (var i = 0; i < sortArray2_Id.length; i++) {
		if (i == 0) {
		// 初回実行時
			sortArray3[count1] = new Array();
			sortArray3[count1][count2] = new Array();
			sortArray3[count1][count2][count3] = inputArray3[sortArray2_Id[i]].toUpperCase() + " |id_" + sortArray2_Id[i];
			tempElement1 = inputArray1[sortArray2_Id[i]];
			tempElement2 = inputArray2[sortArray2_Id[i]];
		} else if ((tempElement1 == inputArray1[sortArray2_Id[i]]) && (tempElement2 == inputArray2[sortArray2_Id[i]])) {
		// 1つ前の第1キーの要素と1つ前の第2キーの要素がともに同じ場合、3次元目を加算し、第3キーの要素を格納
			count3++;
			sortArray3[count1][count2][count3] = inputArray3[sortArray2_Id[i]].toUpperCase() + " |id_" + sortArray2_Id[i];
		} else if ((tempElement1 == inputArray1[sortArray2_Id[i]]) && (tempElement2 != inputArray2[sortArray2_Id[i]])) {
		// 1つ前の第1キーの要素が同じで、1つ前の第2キーの要素が異なる同じ場合、2次元目を加算し、第3キーの要素を格納
			count2++;
			count3 = 0;
			sortArray3[count1][count2] = new Array();
			sortArray3[count1][count2][count3] = inputArray3[sortArray2_Id[i]].toUpperCase() + " |id_" + sortArray2_Id[i];
			tempElement2 = inputArray2[sortArray2_Id[i]];
		} else {
		// 1つ前の第1キーの要素と1つ前の第2キーの要素がともに異なる場合、1次元目を加算し、第3キーの要素を格納
			count1++;
			count2 = 0;
			count3 = 0;
			sortArray3[count1] = new Array();
			sortArray3[count1][count2] = new Array();
			sortArray3[count1][count2][count3] = inputArray3[sortArray2_Id[i]].toUpperCase() + " |id_" + sortArray2_Id[i];
			tempElement1 = inputArray1[sortArray1_Id[i]];
			tempElement2 = inputArray2[sortArray2_Id[i]];
		}
	}

	// 第1キーごとの第2キーごとに第3キーをソート（昇順）
	for (var i = 0; i < sortArray3.length; i++) {
		for (var j = 0; j < sortArray3[i].length; j++) {
			sortArray3[i][j].sort();
		}
	}

	// ソートされた第3キーのID取り出し
	var sortArray3_Id = new Array();
	count = 0;
	for (var i = 0; i < sortArray3.length; i++) {
		for (var j = 0; j < sortArray3[i].length; j++) {
			for (var k = 0; k < sortArray3[i][j].length; k++) {
				sortArray3_Id[count] = sortArray3[i][j][k].split(" |id_")[1];
				count++;
			}
		}
	}

	return sortArray3_Id;
}


// =================================================================================================
// プログラム内の変数を初期化する
// -------------------------------------------------------------------------------------------------
// 概要　　：プログラム内の変数を初期化します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function OffsetValue() {
	idCount = 0;

	arrayAccountTaskId					= new Array();
	arrayAccountTaskNodeId				= new Array();
	arrayAccountTaskAccountId			= new Array();
	arrayAccountTaskAccountCode			= new Array();
	arrayAccountTaskAccountName			= new Array();
	arrayAccountTaskProjectCode			= new Array();
	arrayAccountTaskProjectName			= new Array();
	arrayAccountTaskOutlineNumber		= new Array();
	arrayAccountTaskOutlineSequence		= new Array();
	arrayAccountTaskNodePath			= new Array();
	arrayAccountTaskTaskName			= new Array();
	arrayAccountTaskStartDate			= new Array();
	arrayAccountTaskFinishDate			= new Array();
	arrayAccountTaskPlannedTime			= new Array();
	arrayAccountTaskActualTime			= new Array();
	arrayAccountTaskAssignmentProgress	= new Array();

	error_MSG	= "";
	error_Flag	= 0;
}
