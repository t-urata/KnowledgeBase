
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
// □                                                                                              □
// □                    「実績工数表示ツール」メインプログラム（情報取得系）                      □
// □                                                                                              □
// □ ============================================================================================ □
// □ 概要                                                                                         □
// □ -------------------------------------------------------------------------------------------- □
// □  本ファイルは「実績工数」や「条件設定に利用するアカウントの一覧」など                        □
// □  ［実績工数表示ツール］で行う情報取得系の処理を実施します。                                  □
// □                                                                                              □
// □ ============================================================================================ □
// □ 関数一覧                                                                                     □
// □ -------------------------------------------------------------------------------------------- □
// □  SetDefaultSettingView()             ・・・ 条件設定画面の初期値を設定する                   □
// □  GetAccountDataList()                ・・・ アカウント情報の一覧を取得する                   □
// □  GetAccountDataAndOutputDataList()   ・・・ アカウント情報を取得し、実績工数情報を出力する   □
// □  GetActualTimes()                    ・・・ 実績単位での実績工数情報を取得する               □
// □  DisplayActualTimes()                ・・・ 実績工数（実績単位）を画面に表示する             □
// □  GetDailyActualTimes()               ・・・ 日単位での実績工数情報を取得する                 □
// □  GetMonthlyActualTimes()             ・・・ 月単位での実績工数情報を取得する                 □
// □  DisplayDailyAndMonthlyActualTimes() ・・・ 実績工数（日・月単位）を画面に表示する           □
// □  DisplayDataListHeader()             ・・・ 実績工数情報の項目名（列名）を画面に表示する     □
// □  ReadSampleConfig()                  ・・・ 「Sample.config」ファイルの情報を読み込む        □
// □  ReadLoginAccountData()              ・・・ ログイン情報を読み込む                           □
// □  ChangeSettingView()                 ・・・ 設定画面表示切替の制御                           □
// □  ChangeActualTimeDataListView()      ・・・ 出力結果画面表示切替の制御                       □
// □  CheckHttpRequestResponse()          ・・・ HTTPリクエストのレスポンス情報の確認する         □
// □  GetMonthEndDay()                    ・・・ 月の末日を取得する                               □
// □  CreateDisplayTime()                 ・・・ 表示用時間文字列を作成する                       □
// □  CreateMinuteToHour()                ・・・ 分単位から時間単位の時刻を作成する               □
// □  CreateDisplayDate()                 ・・・ 表示用日付文字列を作成する                       □
// □  DeleteDisplayData()                 ・・・ 画面上に表示された情報を削除する                 □
// □  SetDefaultPeriod()                  ・・・ ［条件設定：期間］の初期値を設定する             □
// □  OutputCSVFile()                     ・・・ 取得した情報をCSVファイルに出力する              □
// □  OffsetValue()                       ・・・ プログラム内の変数を初期化する                   □
// □                                                                                              □
// □ ============================================================================================ □
// □                                                                                              □
// □□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


// =================================================================================================
// 内部共通変数の宣言
// -------------------------------------------------------------------------------------------------
// 概要　　：「実績工数表示ツール」で利用する共通の変数を宣言します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
// ログイン情報
	var loginName;					// ログイン名
	var loginPass;					// パスワード

// 接続先情報
	var ServerName;					// サーバーマシン名（ホスト名）
	var TTFXWebServer;				// Web サイト名

// アカウント一覧用の配列
	var arrayId;					// アカウントIDの配列
	var arrayName;					// アカウント名の配列
	var arrayCode;					// アカウントコードの配列

// 集計用配列の宣言
	var count;						// テーブルのカウンタ
	var arrayTaskId;				// タスクID（実績単位の集計で使用）
	var arrayIdDate;				// "アカウントID_作業日"（日・月単位の集計で使用）
	var arrayAccountCode;			// アカウントコード
	var arrayAccountName;			// アカウント名
	var arrayWorkDate;				// 作業日
	var arrayStartTime;				// 開始時間
	var arrayFinishTime;			// 終了時間
	var arrayWorkingMinutes;		// 作業時間
	var arrayProjectCode;			// プロジェクトコード
	var arrayProjectName;			// プロジェクト名
	var arrayTaskName;				// タスク名
	var arrayMemo;					// メモ

// 出力結果画面の列幅およびフォントサイズの設定
	var widthNo				= 35;	// No.列
	var widthAccountCode	= 120;	// アカウントコード列
	var widthAccountName	= 120;	// アカウント名列
	var widthWorkDate		= 80;	// 日付列
	var widthStartTime		= 75;	// 開始時刻列
	var widthFinishTime		= 75;	// 終了時刻列
	var widthWorkingMinutes	= 80;	// 実績工数列
	var widthProjectCode	= 150;	// プロジェクトコード列
	var widthProjectName	= 200;	// プロジェクト名列
	var widthTaskName		= 200;	// タスク名列
	var widthMemo			= 200;	// メモ列
	var resultFontSize		= 2;	// フォントサイズ

// 入力情報
	var startDate;					// 集計対象期間の開始日（YYYY-MM-DD形式）
	var finishDate;					// 集計対象期間の終了日（YYYY-MM-DD形式）

// エラー処理用変数
	var error_MSG;					// エラーメッセージ
	var error_Flag;					// エラーフラグ（0:エラー無し、1：エラー有り）


// =================================================================================================
// 条件設定画面の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、条件設定画面の初期値を設定します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultSettingView() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

	arrayId		= new Array();
	arrayName	= new Array();
	arrayCode	= new Array();

// 接続先情報の確認
	if (error_Flag == 0) {
		ReadSampleConfig();
	}

// ログイン情報の確認
	if (error_Flag == 0) {
		ReadLoginAccountData();
	}

// アカウント一覧の取得と表示
	if (error_Flag == 0) {
		GetAccountDataList();
	}

// 設定画面の設定
	if (error_Flag == 0) {
	// 期間のセレクトボックスの設定
		SetDefaultPeriod();

	// 設定画面の表示
		ChangeSettingView();
	}

// エラーの表示
	if (error_Flag == 1) {
	// ログイン画面に戻る
		window.location.href = "./login.html";
		alert(error_MSG);
	}
}


// =================================================================================================
// アカウント情報の一覧を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：アカウント一覧を取得し、表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetAccountDataList() {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/system/accounts";
	var queryParameter	= "?limit=0";

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();

// リクエストのレスポンスの確認
	CheckHttpRequestResponse(REQ.status);

	if (error_Flag == 0) {
	// リクエストの結果の取得
		xml.loadXML(REQ.responseText);

		var arrayAccount = xml.getElementsByTagName("account");

	// 配列の初期化
		arrayId		= new Array();
		arrayName	= new Array();
		arrayCode	= new Array();

	// アカウント一覧を配列に格納
		for (var i = 0; i < arrayAccount.length; i++) {
			arrayId[i]								= arrayAccount[i].getElementsByTagName("id")[0].text;
			arrayName["AccountId_" + arrayId[i]]	= arrayAccount[i].getElementsByTagName("name")[0].text;
			arrayCode["AccountId_" + arrayId[i]]	= arrayAccount[i].getElementsByTagName("code")[0].text;
		}

	// アカウント一覧の表示
		var selectAL = document.getElementsByName("accountList")[0];

		for (var i = 0; i < arrayAccount.length; i++) {
		// アカウント名表示用のテキストノード作成
			var optionText = document.createTextNode(arrayName["AccountId_" + arrayId[i]]);

		// Option要素作成
			var newOption = document.createElement("option");

		// value属性にアカウントIDを格納
			newOption.getAttributeNode('value').nodeValue = arrayId[i];

		// 組立
			newOption.appendChild(optionText);
			selectAL.appendChild(newOption);
		}
	}
}


// =================================================================================================
// アカウント情報を取得し、実績工数の情報を出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：指定されたアカウントの情報を取得し、条件に応じた実績工数の情報を出力します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function GetAccountDataAndOutputDataList() {
// 変数の初期化
	error_Flag	= 0;
	error_MSG	= "";

// 入力情報の取得
	var inputStartYear		= document.setting.startYear.value;
	var inputStartMonth		= document.setting.startMonth.value;
	var inputFinishYear		= document.setting.finishYear.value;
	var inputFinishMonth	= document.setting.finishMonth.value;

	startDate	= inputStartYear + "-" + inputStartMonth + "-01";
	finishDate	= inputFinishYear + "-" + inputFinishMonth + "-" + GetMonthEndDay(inputFinishYear, inputFinishMonth);

	var getType = Number(document.setting.setUnit.value);

// テーブルの初期化
	DeleteDisplayData();

// 変数の初期化
	count				= 0;
	arrayIdDate			= new Array();
	arrayTaskId			= new Array();
	arrayAccountCode	= new Array();
	arrayAccountName	= new Array();
	arrayWorkDate		= new Array();
	arrayStartTime		= new Array();
	arrayFinishTime		= new Array();
	arrayWorkingMinutes	= new Array();
	arrayProjectCode	= new Array();
	arrayProjectName	= new Array();
	arrayTaskName		= new Array();
	arrayMemo			= new Array();

// 指定アカウントの実績を取得と集計
	var selectTA	= document.getElementsByName("targetAccount")[0];
	var optionTA	= selectTA.getElementsByTagName("option");

	if (optionTA.length != 0) {
		for (var i = 0; i < optionTA.length; i++) {
			var tempId		= document.setting.targetAccount.options[i].value;
			var tempCode	= arrayCode["AccountId_" + tempId];
			var tempName	= arrayName["AccountId_" + tempId];

		// 実績の取得と集計
			switch (getType) {
				case 0:
					GetActualTimes(tempId, tempCode, tempName);
					break;
				case 1:
					GetDailyActualTimes(tempId, tempCode, tempName);
					break;
				case 2:
					GetMonthlyActualTimes(tempId, tempCode, tempName);
					break;
			}
		}
	} else {
		error_Flag	= 1;
		error_MSG	= error_MSG + "アカウントが指定されていません。";
	}

// 実績の出力
	if (error_Flag == 0) {
	// 実績の有無の確認
		if ((arrayTaskId.length != 0) || (arrayIdDate.length != 0)) {
			switch (getType) {
				case 0:
					if (document.setting.outputSwitch[0].checked) {
						OutputCSVFile(0);
					}
					DisplayDataListHeader(0);
					DisplayActualTimes();
					break;
				case 1:
					if (document.setting.outputSwitch[0].checked) {
						OutputCSVFile(1);
					}
					DisplayDataListHeader(1);
					DisplayDailyAndMonthlyActualTimes();
					break;
				case 2:
					if (document.setting.outputSwitch[0].checked) {
						OutputCSVFile(1);
					}
					DisplayDataListHeader(1);
					DisplayDailyAndMonthlyActualTimes();
					break;
			}

		// 出力結果画面の表示
			ChangeActualTimeDataListView();
		} else {
			error_Flag	= 1;
			error_MSG	= error_MSG + "取得できる実績がありません。";
		}
	}

// エラーの表示
	if (error_Flag == 1) {
		alert(error_MSG);
	}

// 変数の初期化
	OffsetValue();
}


// =================================================================================================
// 実績単位での実績工数情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIで実績工数（実績単位）を取得し、集計用配列に格納します。
// 入力値　：accountId   ･･･ 取得対象アカウントのアカウントID
// 　　　　　accountCode ･･･ 取得対象アカウントのアカウントコード
// 　　　　　accountName ･･･ 取得対象アカウントのアカウント名
// 戻り値　：無
// =================================================================================================
function GetActualTimes(accountId, accountCode, accountName) {
// オブジェクト作成
	var xml = new ActiveXObject("Microsoft.XMLDOM");
	var REQ = new XMLHttpRequest();

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/actualTimes";
	var queryParameter	= "?limit=0&startDate=" + startDate + "&finishDate=" + finishDate;

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayActualTime = xml.getElementsByTagName("actualTime");

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayActualTime.length; i++) {
		arrayTaskId[count]									= arrayActualTime[i].getElementsByTagName("id")[0].text;
		arrayAccountCode["TaskId_" + arrayTaskId[count]]	= accountCode;
		arrayAccountName["TaskId_" + arrayTaskId[count]]	= accountName;
		arrayWorkDate["TaskId_" + arrayTaskId[count]]		= CreateDisplayDate(arrayActualTime[i].getElementsByTagName("workDate")[0].text, 1);
		arrayStartTime["TaskId_" + arrayTaskId[count]]		= CreateDisplayTime(arrayActualTime[i].getElementsByTagName("startTime")[0].text);
		arrayFinishTime["TaskId_" + arrayTaskId[count]]		= CreateDisplayTime(arrayActualTime[i].getElementsByTagName("finishTime")[0].text);
		arrayWorkingMinutes["TaskId_" + arrayTaskId[count]]	= CreateMinuteToHour(arrayActualTime[i].getElementsByTagName("workingMinutes")[0].text);
		arrayProjectCode["TaskId_" + arrayTaskId[count]]	= arrayActualTime[i].getElementsByTagName("projectCode")[0].text;
		arrayProjectName["TaskId_" + arrayTaskId[count]]	= arrayActualTime[i].getElementsByTagName("projectName")[0].text;
		arrayTaskName["TaskId_" + arrayTaskId[count]]		= arrayActualTime[i].getElementsByTagName("taskName")[0].text
		arrayMemo["TaskId_" + arrayTaskId[count]]			= arrayActualTime[i].getElementsByTagName("memo")[0].text;
		count++;
	}
}


// =================================================================================================
// 実績工数（実績単位）を画面に表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：取得した実績工数情報（実績単位）を出力結果画面に表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function DisplayActualTimes() {
// 表示先の指定
	var resultTable	= document.getElementById("resultTable");
	var tableBody	= resultTable.getElementsByTagName("tbody")[0];

	for (var i = 0; i < arrayTaskId.length; i++) {
	// テキストノードの作成
		var tdTextNo				= document.createTextNode(i + 1);
		var tdTextAccountCode		= document.createTextNode(arrayAccountCode["TaskId_" + arrayTaskId[i]]);
		var tdTextAccountName		= document.createTextNode(arrayAccountName["TaskId_" + arrayTaskId[i]]);
		var tdTextWorkDate			= document.createTextNode(arrayWorkDate["TaskId_" + arrayTaskId[i]]);
		var tdTextStartTime			= document.createTextNode(arrayStartTime["TaskId_" + arrayTaskId[i]]);
		var tdTextFinishTime		= document.createTextNode(arrayFinishTime["TaskId_" + arrayTaskId[i]]);
		var tdTextWorkingMinutes	= document.createTextNode(arrayWorkingMinutes["TaskId_" + arrayTaskId[i]]);
		var tdTextProjectCode		= document.createTextNode(arrayProjectCode["TaskId_" + arrayTaskId[i]]);
		var tdTextProjectName		= document.createTextNode(arrayProjectName["TaskId_" + arrayTaskId[i]]);
		var tdTextTaskName			= document.createTextNode(arrayTaskName["TaskId_" + arrayTaskId[i]]);
		var tdTextMemo				= document.createTextNode(arrayMemo["TaskId_" + arrayTaskId[i]]);

	// fontタグの作成
		var tdFontNo				= document.createElement("font");
		var tdFontAccountCode		= document.createElement("font");
		var tdFontAccountName		= document.createElement("font");
		var tdFontWorkDate			= document.createElement("font");
		var tdFontStartTime			= document.createElement("font");
		var tdFontFinishTime		= document.createElement("font");
		var tdFontWorkingMinutes	= document.createElement("font");
		var tdFontProjectCode		= document.createElement("font");
		var tdFontProjectName		= document.createElement("font");
		var tdFontTaskName			= document.createElement("font");
		var tdFontMemo				= document.createElement("font");

	// フォントサイズの設定
		tdFontNo.getAttributeNode('size').nodeValue				= resultFontSize;
		tdFontAccountCode.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontAccountName.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontWorkDate.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontStartTime.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontFinishTime.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontWorkingMinutes.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontProjectCode.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontProjectName.getAttributeNode('size').nodeValue	= resultFontSize;
		tdFontTaskName.getAttributeNode('size').nodeValue		= resultFontSize;
		tdFontMemo.getAttributeNode('size').nodeValue			= resultFontSize;

	// tdタグの作成
		var tdElementNo				= document.createElement("td");
		var tdElementAccountCode	= document.createElement("td");
		var tdElementAccountName	= document.createElement("td");
		var tdElementWorkDate		= document.createElement("td");
		var tdElementStartTime		= document.createElement("td");
		var tdElementFinishTime		= document.createElement("td");
		var tdElementWorkingMinutes	= document.createElement("td");
		var tdElementProjectCode	= document.createElement("td");
		var tdElementProjectName	= document.createElement("td");
		var tdElementTaskName		= document.createElement("td");
		var tdElementMemo			= document.createElement("td");

	// 列幅の設定
		tdElementNo.getAttributeNode('width').nodeValue				= widthNo;
		tdElementAccountCode.getAttributeNode('width').nodeValue	= widthAccountCode;
		tdElementAccountName.getAttributeNode('width').nodeValue	= widthAccountName;
		tdElementWorkDate.getAttributeNode('width').nodeValue		= widthWorkDate;
		tdElementStartTime.getAttributeNode('width').nodeValue		= widthStartTime;
		tdElementFinishTime.getAttributeNode('width').nodeValue		= widthFinishTime;
		tdElementWorkingMinutes.getAttributeNode('width').nodeValue	= widthWorkingMinutes;
		tdElementProjectCode.getAttributeNode('width').nodeValue	= widthProjectCode;
		tdElementProjectName.getAttributeNode('width').nodeValue	= widthProjectName;
		tdElementTaskName.getAttributeNode('width').nodeValue		= widthTaskName;
		tdElementMemo.getAttributeNode('width').nodeValue			= widthMemo;

	// 表示位置の設定
		tdElementWorkDate.getAttributeNode('align').nodeValue		= "center";
		tdElementStartTime.getAttributeNode('align').nodeValue		= "center";
		tdElementFinishTime.getAttributeNode('align').nodeValue		= "center";
		tdElementWorkingMinutes.getAttributeNode('align').nodeValue	= "right";

	// trタグの作成
		var trElement = document.createElement("tr");

	// fontタグにテキストノードを追加
		tdFontNo.appendChild(tdTextNo);
		tdFontAccountCode.appendChild(tdTextAccountCode);
		tdFontAccountName.appendChild(tdTextAccountName);
		tdFontWorkDate.appendChild(tdTextWorkDate);
		tdFontStartTime.appendChild(tdTextStartTime);
		tdFontFinishTime.appendChild(tdTextFinishTime);
		tdFontWorkingMinutes.appendChild(tdTextWorkingMinutes);
		tdFontProjectCode.appendChild(tdTextProjectCode);
		tdFontProjectName.appendChild(tdTextProjectName);
		tdFontTaskName.appendChild(tdTextTaskName);
		tdFontMemo.appendChild(tdTextMemo);

	// tdタグにfontタグを追加
		tdElementNo.appendChild(tdFontNo);
		tdElementAccountCode.appendChild(tdFontAccountCode);
		tdElementAccountName.appendChild(tdFontAccountName);
		tdElementWorkDate.appendChild(tdFontWorkDate);
		tdElementStartTime.appendChild(tdFontStartTime);
		tdElementFinishTime.appendChild(tdFontFinishTime);
		tdElementWorkingMinutes.appendChild(tdFontWorkingMinutes);
		tdElementProjectCode.appendChild(tdFontProjectCode);
		tdElementProjectName.appendChild(tdFontProjectName);
		tdElementTaskName.appendChild(tdFontTaskName);
		tdElementMemo.appendChild(tdFontMemo);
		
	// trタグ内にtdタグ内容を追加
		trElement.appendChild(tdElementNo);				// No.
		trElement.appendChild(tdElementAccountCode);	// アカウントコード
		trElement.appendChild(tdElementAccountName);	// アカウント名
		trElement.appendChild(tdElementWorkDate);		// 日付
		trElement.appendChild(tdElementStartTime);		// 開始時刻
		trElement.appendChild(tdElementFinishTime);		// 終了時刻
		trElement.appendChild(tdElementWorkingMinutes);	// 作業時間
		trElement.appendChild(tdElementProjectCode);	// プロジェクトコード
		trElement.appendChild(tdElementProjectName);	// プロジェクト名
		trElement.appendChild(tdElementTaskName);		// タスク名
		trElement.appendChild(tdElementMemo);			// メモ

	// tbodyタグ内にtrタグの内容を追加
		tableBody.appendChild(trElement);
	}
}


// =================================================================================================
// 日単位での実績工数情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIで実績工数（日単位）を取得し、集計用配列に格納します。
// 入力値　：accountId   ･･･ 取得対象アカウントのアカウントID
// 　　　　　accountCode ･･･ 取得対象アカウントのアカウントコード
// 　　　　　accountName ･･･ 取得対象アカウントのアカウント名
// 戻り値　：無
// =================================================================================================
function GetDailyActualTimes(accountId, accountCode, accountName) {
// オブジェクト作成
	var xml	= new ActiveXObject("Microsoft.XMLDOM");
	var REQ	= new XMLHttpRequest();

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/dailyActualTimes";
	var queryParameter	= "?limit=0&startDate=" + startDate + "&finishDate=" + finishDate;

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayDailyActualTime = xml.getElementsByTagName("dailyActualTime");

// 取得情報を各項目用配列に再格納
	for (var i = 0; i < arrayDailyActualTime.length; i++) {
		var workDate = CreateDisplayDate(arrayDailyActualTime[i].getElementsByTagName("workDate")[0].text, 1);

	// 実績工数が0以外のデータを格納
		if (arrayDailyActualTime[i].getElementsByTagName("workingMinutes")[0].text != 0) {
			arrayIdDate[count]						= accountId + "_" + workDate;
			arrayAccountCode[arrayIdDate[count]]	= accountCode;
			arrayAccountName[arrayIdDate[count]]	= accountName;
			arrayWorkDate[arrayIdDate[count]]		= workDate;
			arrayWorkingMinutes[arrayIdDate[count]]	= CreateMinuteToHour(arrayDailyActualTime[i].getElementsByTagName("workingMinutes")[0].text);
			count++;
		}
	}
}


// =================================================================================================
// 月単位での実績工数情報を取得する
// -------------------------------------------------------------------------------------------------
// 概要　　：TimeTracker FX Web APIで実績工数（日単位）を取得し、
// 　　　　　月単位に集計しなおして、集計用配列に格納します。
// 入力値　：accountId   ･･･ 取得対象アカウントのアカウントID
// 　　　　　accountCode ･･･ 取得対象アカウントのアカウントコード
// 　　　　　accountName ･･･ 取得対象アカウントのアカウント名
// 戻り値　：無
// =================================================================================================
function GetMonthlyActualTimes(accountId, accountCode, accountName) {
// オブジェクト作成
	var xml	= new ActiveXObject("Microsoft.XMLDOM");
	var REQ	= new XMLHttpRequest();

// 送信先URL情報の設定
	var url				= "http://" + ServerName + "/" + TTFXWebServer + "/XmlWebService.svc";
	var objectName		= "/accounts/" + accountId + "/dailyActualTimes";
	var queryParameter	= "?limit=0&startDate=" + startDate + "&finishDate=" + finishDate;

// 送信用URLを生成
	url = url + objectName + queryParameter;

// リクエストの作成・送信・結果の取得
	REQ.open('GET', url, false, loginName, loginPass);
	REQ.setRequestHeader("Content-Type","text/xml; charset=utf-8");
	REQ.send();
	xml.loadXML(REQ.responseText);

// 取得したデータを配列に格納
	var arrayDailyActualTime = xml.getElementsByTagName("dailyActualTime");

// 初めの月を取得
	if (arrayDailyActualTime.length != 0) {
		var tempMonth = new Date(arrayDailyActualTime[0].getElementsByTagName("workDate")[0].text);
		tempMonth = tempMonth.getMonth();
	}

// 作業時間集計用変数
	var wokingTime = 0;

// 取得した実績を月単位で集計し、各項目用配列に再格納
	for (var i = 0; i < arrayDailyActualTime.length; i++) {
		var thisDate	= new Date(arrayDailyActualTime[i].getElementsByTagName("workDate")[0].text);
		var thisMonth	= thisDate.getMonth();

	// 前日と同月の場合、作業時間を加算
		if (tempMonth == thisMonth) {
			wokingTime = wokingTime + Number(arrayDailyActualTime[i].getElementsByTagName("workingMinutes")[0].text);
		}

	// 月が変わったときに前日までの情報を配列に再格納
		if (tempMonth != thisMonth) {
			if (wokingTime != 0) {
				var workDate = CreateDisplayDate(arrayDailyActualTime[i-1].getElementsByTagName("workDate")[0].text, 0);

				arrayIdDate[count]						= accountId + "_" + workDate;
				arrayAccountCode[arrayIdDate[count]]	= accountCode;
				arrayAccountName[arrayIdDate[count]]	= accountName;
				arrayWorkDate[arrayIdDate[count]]		= workDate;
				arrayWorkingMinutes[arrayIdDate[count]]	= CreateMinuteToHour(wokingTime);

				count++;

				// 初期化
				tempMonth	= thisMonth;
				wokingTime	= Number(arrayDailyActualTime[i].getElementsByTagName("workingMinutes")[0].text);
			}
		}

		// 最後のデータを配列に再格納
		if (i == arrayDailyActualTime.length - 1) {
			if (wokingTime != 0) {
				var workDate = CreateDisplayDate(arrayDailyActualTime[i].getElementsByTagName("workDate")[0].text, 0);

				arrayIdDate[count]						= accountId + "_" + workDate;
				arrayAccountCode[arrayIdDate[count]]	= accountCode;
				arrayAccountName[arrayIdDate[count]]	= accountName;
				arrayWorkDate[arrayIdDate[count]]		= workDate;
				arrayWorkingMinutes[arrayIdDate[count]]	= CreateMinuteToHour(wokingTime);

				count++;
			}
		}
	}
}


// =================================================================================================
// 実績工数（日・月単位）を画面に表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：取得・集計した実績工数情報（日・月単位）を出力結果画面に表示します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function DisplayDailyAndMonthlyActualTimes() {
// No.列用カウンタ
	var NUM = 0;

// 表示先の指定
	var resultTable	= document.getElementById("resultTable");
	var tableBody	= resultTable.getElementsByTagName("tbody")[0];

	for (var i = 0; i < arrayIdDate.length; i++) {
		var wokingTime = arrayWorkingMinutes[arrayIdDate[i]];

	// 実績時間があるもののみ表示
		if (wokingTime != 0) {
			NUM++;

		// テキストノードの作成
			var tdTextNo				= document.createTextNode(NUM);
			var tdTextAccountCode		= document.createTextNode(arrayAccountCode[arrayIdDate[i]]);
			var tdTextAccountName		= document.createTextNode(arrayAccountName[arrayIdDate[i]]);
			var tdTextWorkDate			= document.createTextNode(arrayWorkDate[arrayIdDate[i]]);
			var tdTextWorkingMinutes	= document.createTextNode(arrayWorkingMinutes[arrayIdDate[i]]);

		// fontタグの作成
			var tdFontNo				= document.createElement("font");
			var tdFontAccountCode		= document.createElement("font");
			var tdFontAccountName		= document.createElement("font");
			var tdFontWorkDate			= document.createElement("font");
			var tdFontWorkingMinutes	= document.createElement("font");

		// フォントサイズの設定
			tdFontNo.getAttributeNode('size').nodeValue				= resultFontSize;
			tdFontAccountCode.getAttributeNode('size').nodeValue	= resultFontSize;
			tdFontAccountName.getAttributeNode('size').nodeValue	= resultFontSize;
			tdFontWorkDate.getAttributeNode('size').nodeValue		= resultFontSize;
			tdFontWorkingMinutes.getAttributeNode('size').nodeValue	= resultFontSize;

		// tdタグの作成
			var tdElementNo				= document.createElement("td");
			var tdElementAccountCode	= document.createElement("td");
			var tdElementAccountName	= document.createElement("td");
			var tdElementWorkDate		= document.createElement("td");
			var tdElementWorkingMinutes	= document.createElement("td");

		// 列幅の設定
			tdElementNo.getAttributeNode('width').nodeValue				= widthNo;
			tdElementAccountCode.getAttributeNode('width').nodeValue	= widthAccountCode;
			tdElementAccountName.getAttributeNode('width').nodeValue	= widthAccountName;
			tdElementWorkDate.getAttributeNode('width').nodeValue		= widthWorkDate;
			tdElementWorkingMinutes.getAttributeNode('width').nodeValue	= widthWorkingMinutes;

		// 表示位置の設定
			tdElementWorkDate.getAttributeNode('align').nodeValue		= "center";
			tdElementWorkingMinutes.getAttributeNode('align').nodeValue	= "right";

		// trタグの作成
			var trElement = document.createElement("tr");

		// fontタグにテキストノードを追加
			tdFontNo.appendChild(tdTextNo);
			tdFontAccountCode.appendChild(tdTextAccountCode);
			tdFontAccountName.appendChild(tdTextAccountName);
			tdFontWorkDate.appendChild(tdTextWorkDate);
			tdFontWorkingMinutes.appendChild(tdTextWorkingMinutes);

		// tdタグにfontタグを追加
			tdElementNo.appendChild(tdFontNo);
			tdElementAccountCode.appendChild(tdFontAccountCode);
			tdElementAccountName.appendChild(tdFontAccountName);
			tdElementWorkDate.appendChild(tdFontWorkDate);
			tdElementWorkingMinutes.appendChild(tdFontWorkingMinutes);

		// trタグ内にtdタグ内容を追加
			trElement.appendChild(tdElementNo);				// No.
			trElement.appendChild(tdElementAccountCode);	// アカウントコード
			trElement.appendChild(tdElementAccountName);	// アカウント名
			trElement.appendChild(tdElementWorkDate);		// 日付
			trElement.appendChild(tdElementWorkingMinutes);	// 作業時間

		// tbodyタグ内にtrタグの内容を追加
			tableBody.appendChild(trElement);
		}
	}
}


// =================================================================================================
// 実績工数情報の項目名（列名）を画面上に表示する
// -------------------------------------------------------------------------------------------------
// 概要　　：出力する種類に応じて、出力結果の項目名（列名）を画面に表示します。
// 入力値　：type ･･･ 単位の種類（0:実績単位,1:日または月単位）
// 戻り値　：無
// =================================================================================================
function DisplayDataListHeader(type) {
	var resultTable	= document.getElementById("resultTable");
	var tableHead	= resultTable.getElementsByTagName("thead")[0];

// テキストノードの作成
	var tdTextNo				= document.createTextNode("No.");
	var tdTextAccountCode		= document.createTextNode("アカウントコード");
	var tdTextAccountName		= document.createTextNode("アカウント名");
	var tdTextWorkDate			= document.createTextNode("日付");
	var tdTextStartTime			= document.createTextNode("開始時刻");
	var tdTextFinishTime		= document.createTextNode("終了時刻");
	var tdTextWorkingMinutes	= document.createTextNode("実績工数");
	var tdTextProjectCode		= document.createTextNode("プロジェクトコード");
	var tdTextProjectName		= document.createTextNode("プロジェクト名");
	var tdTextTaskName			= document.createTextNode("タスク名");
	var tdTextMemo				= document.createTextNode("メモ");

// fontタグの作成
	var tdFontNo				= document.createElement("font");
	var tdFontAccountCode		= document.createElement("font");
	var tdFontAccountName		= document.createElement("font");
	var tdFontWorkDate			= document.createElement("font");
	var tdFontStartTime			= document.createElement("font");
	var tdFontFinishTime		= document.createElement("font");
	var tdFontWorkingMinutes	= document.createElement("font");
	var tdFontProjectCode		= document.createElement("font");
	var tdFontProjectName		= document.createElement("font");
	var tdFontTaskName			= document.createElement("font");
	var tdFontMemo				= document.createElement("font");

// フォントサイズの設定
	tdFontNo.getAttributeNode('size').nodeValue				= resultFontSize;
	tdFontAccountCode.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontAccountName.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontWorkDate.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontStartTime.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontFinishTime.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontWorkingMinutes.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontProjectCode.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontProjectName.getAttributeNode('size').nodeValue	= resultFontSize;
	tdFontTaskName.getAttributeNode('size').nodeValue		= resultFontSize;
	tdFontMemo.getAttributeNode('size').nodeValue			= resultFontSize;

// td要素の作成
	var tdElementNo				= document.createElement("td");
	var tdElementAccountCode	= document.createElement("td");
	var tdElementAccountName	= document.createElement("td");
	var tdElementWorkDate		= document.createElement("td");
	var tdElementStartTime		= document.createElement("td");
	var tdElementFinishTime		= document.createElement("td");
	var tdElementWorkingMinutes	= document.createElement("td");
	var tdElementProjectCode	= document.createElement("td");
	var tdElementProjectName	= document.createElement("td");
	var tdElementTaskName		= document.createElement("td");
	var tdElementMemo			= document.createElement("td");

// テーブルの幅の設定
	var widthTable	= widthNo + widthAccountCode + widthAccountName + widthWorkDate + widthWorkingMinutes + 22;

	if (type == 0) {
		widthTable	= widthTable + widthStartTime + widthFinishTime
					+ widthProjectCode + widthProjectName + widthTaskName + widthMemo + 24;
	}

	resultTable.getAttributeNode('width').nodeValue = widthTable;

// 列幅の設定
	tdElementNo.getAttributeNode('width').nodeValue				= widthNo;
	tdElementAccountCode.getAttributeNode('width').nodeValue	= widthAccountCode;
	tdElementAccountName.getAttributeNode('width').nodeValue	= widthAccountName;
	tdElementWorkDate.getAttributeNode('width').nodeValue		= widthWorkDate;
	tdElementStartTime.getAttributeNode('width').nodeValue		= widthStartTime;
	tdElementFinishTime.getAttributeNode('width').nodeValue		= widthFinishTime;
	tdElementWorkingMinutes.getAttributeNode('width').nodeValue	= widthWorkingMinutes;
	tdElementProjectCode.getAttributeNode('width').nodeValue	= widthProjectCode;
	tdElementProjectName.getAttributeNode('width').nodeValue	= widthProjectName;
	tdElementTaskName.getAttributeNode('width').nodeValue		= widthTaskName;
	tdElementMemo.getAttributeNode('width').nodeValue			= widthMemo;

// tr要素の作成
	var trElement = document.createElement("tr");

// fontタグにテキストノードを追加
	tdFontNo.appendChild(tdTextNo);
	tdFontAccountCode.appendChild(tdTextAccountCode);
	tdFontAccountName.appendChild(tdTextAccountName);
	tdFontWorkDate.appendChild(tdTextWorkDate);
	tdFontStartTime.appendChild(tdTextStartTime);
	tdFontFinishTime.appendChild(tdTextFinishTime);
	tdFontWorkingMinutes.appendChild(tdTextWorkingMinutes);
	tdFontProjectCode.appendChild(tdTextProjectCode);
	tdFontProjectName.appendChild(tdTextProjectName);
	tdFontTaskName.appendChild(tdTextTaskName);
	tdFontMemo.appendChild(tdTextMemo);

// tdタグにfontタグを追加
	tdElementNo.appendChild(tdFontNo);
	tdElementAccountCode.appendChild(tdFontAccountCode);
	tdElementAccountName.appendChild(tdFontAccountName);
	tdElementWorkDate.appendChild(tdFontWorkDate);
	tdElementStartTime.appendChild(tdFontStartTime);
	tdElementFinishTime.appendChild(tdFontFinishTime);
	tdElementWorkingMinutes.appendChild(tdFontWorkingMinutes);
	tdElementProjectCode.appendChild(tdFontProjectCode);
	tdElementProjectName.appendChild(tdFontProjectName);
	tdElementTaskName.appendChild(tdFontTaskName);
	tdElementMemo.appendChild(tdFontMemo);

// trタグ内にtdタグ内容を追加
	trElement.appendChild(tdElementNo);					// No,
	trElement.appendChild(tdElementAccountCode);		// アカウントコード
	trElement.appendChild(tdElementAccountName);		// アカウント名
	trElement.appendChild(tdElementWorkDate);			// 作業日

	if (type == 0) {
		trElement.appendChild(tdElementStartTime);		// 開始時刻
		trElement.appendChild(tdElementFinishTime);		// 終了時刻
	}

	trElement.appendChild(tdElementWorkingMinutes);		// 作業時間

	if (type == 0) {
		trElement.appendChild(tdElementProjectCode);	// プロジェクトコード
		trElement.appendChild(tdElementProjectName);	// プロジェクト名
		trElement.appendChild(tdElementTaskName);		// タスク名
		trElement.appendChild(tdElementMemo);			// メモ
	}

// theadタグ内にtrタグの内容を追加
	tableHead.appendChild(trElement);
}


// =================================================================================================
// 「Sample.config」ファイルの情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：「Sample.config」ファイルの情報を読み込み、サーバーマシン名とWebサイト名を取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadSampleConfig() {
// オブジェクト作成
	var ConfigFile = new ActiveXObject("Microsoft.XMLDOM");

// configファイルの読み込み
	ConfigFile.load("./../Sample.config");

	if (ConfigFile.getElementsByTagName("SampleConfig").length == 0) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "Sample.configが正常に読み込めません。";
	} else {
	// サーバーマシン名とWeb サイト名の取得
		ServerName		= ConfigFile.getElementsByTagName("ServerName")[0].text;	// サーバーマシン名（ホスト名）
		TTFXWebServer	= ConfigFile.getElementsByTagName("TTFXWebServer")[0].text;	// Webサイト名

		if (ServerName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "Sample.configのServerNameにホスト名が入力されていません。\n";
		}

		if (TTFXWebServer == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "Sample.configのTTFXWebServerにWebサイト名が入力されていません。";
		}
	}
}


// =================================================================================================
// ログイン情報を読み込む
// -------------------------------------------------------------------------------------------------
// 概要　　：URLのクエリパラメータのログイン情報を読み込み、ログイン名とパスワードを取得します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ReadLoginAccountData() {
// URLのクエリパラメータの取得
	var loginNameAndPass = location.search;

	if (loginNameAndPass == "") {
		error_Flag	= 1;
		error_MSG	= error_MSG + "login.htmlよりツールを起動してください。";
	} else {
		loginNameAndPass	= loginNameAndPass.substring(1,loginNameAndPass.length);
		var arrayQP			= loginNameAndPass.split("&");

	// ログイン名とパスワードを取得
		loginName	= arrayQP[0].split("=")[1];
		loginPass	= arrayQP[1].split("=")[1];

		if (loginName == "") {
			error_Flag	= 1;
			error_MSG	= error_MSG + "ログイン名を入力してください。";
		}
	}
}


// =================================================================================================
// 設定画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面を非表示にし、設定画面を切り替えます。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeSettingView() {
	document.getElementById("settingView").style.display	= "block";
	document.getElementById("resultView").style.display		= "none";
}


// =================================================================================================
// 出力結果画面表示切替の制御
// -------------------------------------------------------------------------------------------------
// 概要　　：設定画面を非表示にし、出力結果画面を切り替えます。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function ChangeActualTimeDataListView() {
	document.getElementById("settingView").style.display	= "none";
	document.getElementById("resultView").style.display		= "block";
}


// =================================================================================================
// HTTPリクエストのレスポンス情報の確認する
// -------------------------------------------------------------------------------------------------
// 概要　　：HTTPリクエストのレスポンスに応じて、エラーメッセージを設定します。
// 入力値　：responseCode ･･･ レスポンスコード
// 戻り値　：無
// =================================================================================================
function CheckHttpRequestResponse(responseCode) {
	switch (responseCode) {
		case 200:
		//	error_MSG = error_MSG + "エラーはありません。";
			break;
		case 400:
			error_Flag	= 1;
			error_MSG	= error_MSG + "パラメータやリクエストに不備があります。";
			break;
		case 401:
			error_Flag	= 1;
			error_MSG	= error_MSG + "認証に失敗しました。\n";
			error_MSG	= error_MSG + "ログイン名またはパスワードに誤りがあります。\n";
			break;
		case 404:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したソース(URI)が存在しません。";
			break;
		case 405:
			error_Flag	= 1;
			error_MSG	= error_MSG + "指定したHTTPメソッドが使用できません。";
			break;
		case 411:
			error_Flag	= 1;
			error_MSG	= error_MSG + "HTTP リクエストヘッダにContent-Lengthが指定されていません。";
			break;
		case 500:
			error_Flag	= 1;
			error_MSG	= error_MSG + "サーバーでエラーが発生しました。";
			break;
		default:
			error_Flag	= 1;
			error_MSG	= error_MSG + "エラーが発生しました。\n";
			error_MSG	= error_MSG + "Sample.configに不備がある可能性があります。";
			break;
	}
}


// =================================================================================================
// 月の末日の取得
// -------------------------------------------------------------------------------------------------
// 概要　　：年と月の情報をもとに、月の末日を取得します。
// 入力値　：year  ･･･ 年
// 　　　　　month ･･･ 月
// 戻り値　：末日の日
// =================================================================================================
function GetMonthEndDay(year, month) {
	var endDay = new Date(year, month, 0);
	return(endDay.getDate());
}


// =================================================================================================
// 表示用時間文字列を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：表示用時間文字列（hh:mm形式）を作成します。
// 入力値　：strTime ･･･ 時間
// 戻り値　：hh:mm形式の時間
// =================================================================================================
function CreateDisplayTime(strTime) {
// 入力値から時と分を取得
	var inputDate	= new Date(strTime);		// 日付
	var hh			= inputDate.getHours();		// 時
	var mm			= inputDate.getMinutes();	// 分

// 1桁の場合に0を付与
	if (hh < 10) {
		hh = "0" + hh;
	}
	if (mm < 10) {
		mm = "0" + mm;
	}

// 表示用時間文字列（hh:mm形式）の作成
	return(hh + ":" + mm);
}


// =================================================================================================
// 分単位から時間単位に変換した時刻を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：分単位から時間単位に変換し、小数第2位まで表示した文字列を作成します。
// 入力値　：minute ･･･ 分
// 戻り値　：小数第2位まで表示した時間の文字列
// =================================================================================================
function CreateMinuteToHour(minute) {
// 分単位から時間単位に変換
	var tempTime = minute / 60;

// 小数第2位まで文字列に変換
	return(tempTime.toFixed(2));
}


// =================================================================================================
// 表示用日付文字列を作成する
// -------------------------------------------------------------------------------------------------
// 概要　　：表示用日付文字列（YYYY/MMまたはYYYY/MM/DD形式）を作成します。
// 入力値　：strDate ･･･ 日付
// 　　　　　dayFlag ･･･ 日の表示のフラグ（0:表示しない（YYYY/MM形式）,1:表示する（YYYY/MM/DD形式））
// 戻り値　：日付
// =================================================================================================
function CreateDisplayDate(strDate, dayFlag) {
// 入力値から年、月、日を取得
	var inputDate	= new Date(strDate);		// 日付
	var YYYY		= inputDate.getYear();		// 年
	var MM			= inputDate.getMonth() + 1;	// 月
	var DD			= inputDate.getDate();		// 日

// 1桁の場合に0を付与
	if (MM < 10) {
		MM = "0" + MM;
	}
	if (DD < 10) {
		DD = "0" + DD;
	}

// フラグに応じた表示用日付文字列の作成
	if (dayFlag == 0) {
		return(YYYY + "/" + MM);
	} else {
		return(YYYY + "/" + MM + "/" + DD);
	}
}


// =================================================================================================
// 画面上に表示された情報を削除する
// -------------------------------------------------------------------------------------------------
// 概要　　：出力結果画面に表示された情報を削除します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function DeleteDisplayData() {
// 削除箇所の指定
	var resultTable = document.getElementById("resultTable");

// thead内の情報を削除
	var tableHead	= resultTable.getElementsByTagName("thead")[0];
	var arrayTr		= tableHead.getElementsByTagName("tr");

	if (arrayTr.length != 0) {
	// trタグの削除
		tableHead.removeChild(arrayTr[0]);
	}

// tbody内の情報を削除
	var tableBody	= resultTable.getElementsByTagName("tbody")[0];
	var arrayTr		= tableBody.getElementsByTagName("tr");
	var arrayTrLen	= arrayTr.length;

	for (var y = 0; y < arrayTrLen; y++) {
	// trタグの削除
		tableBody.removeChild(arrayTr[0]);
	}

}

// =================================================================================================
// ［条件設定：期間］の初期値を設定する
// -------------------------------------------------------------------------------------------------
// 概要　　：［条件設定：期間］のセレクトボックスに当年と前後1年を年月を設定し、
// 　　　　　初期選択値として当年と当月を選択する。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function SetDefaultPeriod() {
// 現在の日付の取得
	var today		= new Date();		// 現在の日時
	var thisYear	= today.getYear();	// 現在の年
	var thisMonth	= today.getMonth();	// 現在の月

// 期間のセレクトボックスに当年と前後1年を設定
	for (var i = 0; i < 3; i++) {
		document.setting.startYear.options[i].text		= thisYear - 1 + i;
		document.setting.startYear.options[i].value		= thisYear - 1 + i;
		document.setting.finishYear.options[i].text		= thisYear - 1 + i;
		document.setting.finishYear.options[i].value	= thisYear - 1 + i;
	}

// 初期選択値の設定
	document.setting.startYear.selectedIndex	= 1;
	document.setting.startMonth.selectedIndex	= thisMonth;

	document.setting.finishYear.selectedIndex	= 1;
	document.setting.finishMonth.selectedIndex	= thisMonth;
}


// =================================================================================================
// 取得した情報をCSVファイルに出力する
// -------------------------------------------------------------------------------------------------
// 概要　　：出力する単位の種類に応じて、情報をCSVファイルに出力します。
// 入力値　：type ･･･ 単位の種類（0:実績単位,1:日または月単位）
// 戻り値　：無
// =================================================================================================
function OutputCSVFile(type) {
// 上書き確認用フラグ
	var overwriteFlag = true;

// 出力先に指定されているパスとファイル名を取得
	var filename = document.getElementById("output").value;

// 拡張子の確認
	var extension = filename.slice(-4, filename.length);

	if ((extension != ".csv") && (extension != ".CSV")) {
		filename = filename + ".csv";
	}

// ファイル出力
	try {
	// ファイルシステムオブジェクトの生成
		var FSO =new ActiveXObject("Scripting.FileSystemObject");

	// ファイルの有無の確認
		if (FSO.FileExists(filename)) {
			overwriteFlag = confirm("すでにCSVファイルが存在します。\n上書きしてもよろしいですか。");
		}

	// ファイル出力実施
		if (overwriteFlag) {
			var file = FSO.OpenTextFile(filename, 2, true, 0); // 書き込みモード、新規ファイル作成
			var STR;

		// 実績単位の出力
			if (type == 0) {
			// ヘッダー出力
				STR = "No.,アカウントコード,アカウント名,日付,開始時刻,終了時刻,実績工数,プロジェクトコード,プロジェクト名,タスク名,メモ\n";

			// 実績の出力
				for (var i = 0; i < arrayTaskId.length; i++) {
					var NUM = i + 1;
					STR = STR + NUM
							+ "," + arrayAccountCode["TaskId_" + arrayTaskId[i]]
							+ "," + arrayAccountName["TaskId_" + arrayTaskId[i]]
							+ "," + arrayWorkDate["TaskId_" + arrayTaskId[i]]
							+ "," + arrayStartTime["TaskId_" + arrayTaskId[i]]
							+ "," + arrayFinishTime["TaskId_" + arrayTaskId[i]]
							+ "," + arrayWorkingMinutes["TaskId_" + arrayTaskId[i]]
							+ "," + arrayProjectCode["TaskId_" + arrayTaskId[i]]
							+ "," + arrayProjectName["TaskId_" + arrayTaskId[i]]
							+ "," + arrayTaskName["TaskId_" + arrayTaskId[i]]
							+ "," + arrayMemo["TaskId_" + arrayTaskId[i]] + "\n";
				}
			}

		// 日・月単位の出力
			if (type == 1) {
			// ヘッダー出力
				STR = "No.,アカウントコード,アカウント名,日付,実績工数\n";

			// 実績の出力
				for (var i = 0; i < arrayIdDate.length; i++) {
					var NUM = i + 1;
					STR = STR + NUM
							+ "," + arrayAccountCode[arrayIdDate[i]]
							+ "," + arrayAccountName[arrayIdDate[i]]
							+ "," + arrayWorkDate[arrayIdDate[i]]
							+ "," + arrayWorkingMinutes[arrayIdDate[i]] + "\n";
				}
			}

		// ファイルに書き込み
			file.Write(STR);
			file.Close();
			confirm("以下にCSVファイルを出力しました。\n" + filename);
		} else {
			confirm("CSVファイルの出力はキャンセルされました。");
		}
	} catch (e) {
		error_Flag	= 1;
		error_MSG	= error_MSG + "ファイル出力エラー\n";
		error_MSG	= error_MSG + e.description;
	}
}


// =================================================================================================
// プログラム内の変数を初期化する
// -------------------------------------------------------------------------------------------------
// 概要　　：プログラム内の変数を初期化します。
// 入力値　：無
// 戻り値　：無
// =================================================================================================
function OffsetValue() {
	count = 0;

	arrayIdDate			= new Array();
	arrayTaskId			= new Array();
	arrayAccountCode	= new Array();
	arrayAccountName	= new Array();
	arrayWorkDate		= new Array();
	arrayStartTime		= new Array();
	arrayFinishTime		= new Array();
	arrayWorkingMinutes	= new Array();
	arrayProjectCode	= new Array();
	arrayProjectName	= new Array();
	arrayTaskName		= new Array();
	arrayMemo			= new Array();

	error_MSG	= "";
	error_Flag	= 0;
}
